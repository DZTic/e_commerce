---
title: Yoshi
type: person
discord_id: 725240620611928076
created: 2026-05-01
tags: #person #discord #hermes
---

# Yoshi

## 📋 Informations

**Nom**: Yoshi
**ID Discord**: 725240620611928076
**Rôle**: Membre du Club des Agents
**Bot associé**: Hermes Agent (ID: 1498378724163321958)

## 🤖 Contexte Discord

### Serveur "Club des Agents"

Yoshi est l'un des membres du serveur "Club des Agents" et possède son propre bot dédié.

| Personne   | ID Discord         | Bot          | ID Bot              |
| ---------- | ------------------ | ------------ | ------------------- |
| Yoshi      | 725240620611928076 | Hermes Agent | 1498378724163321958 |
| Lama2000   | 941378796186128434 | Hermes Bot   | 1499114789283168409 |
| DZGrievous | 677139571754008576 | Hermes Agent | 1498378724163321958 |

## 🔗 Ressources Connexes

- [[Club des Agents]] - Serveur Discord
- [[Hermes Agent (Yoshi)]] - Bot associé
- [[Communication inter-agents]] - Système de communication

---
*Créé le 1 mai 2026*
*Statut: Actif*
