#!/usr/bin/env python3
"""
Discord Conversation Logger
Système automatique pour enregistrer les conversations Discord dans Obsidian.
"""

import os
import json
from datetime import datetime
from pathlib import Path


class DiscordConversationLogger:
    """Logger pour les conversations Discord."""

    def __init__(self, vault_path: str):
        """
        Initialiser le logger.

        Args:
            vault_path: Chemin vers le vault Obsidian
        """
        self.vault_path = Path(vault_path)
        self.discord_path = self.vault_path / "Discord" / "Club-des-Agents"
        self.conversations_path = self.discord_path / "Conversations"

        # Créer les dossiers si nécessaire
        self.discord_path.mkdir(parents=True, exist_ok=True)
        self.conversations_path.mkdir(parents=True, exist_ok=True)

    def log_conversation(self, conversation_data: dict) -> str:
        """
        Enregistrer une conversation dans Obsidian.

        Args:
            conversation_data: Données de la conversation

        Returns:
            Chemin du fichier créé
        """
        # Créer le nom du fichier
        date_str = datetime.now().strftime("%Y-%m-%d")
        title = conversation_data.get("title", "Conversation sans titre")
        filename = f"{date_str}_{title}.md"
        filepath = self.conversations_path / filename

        # Créer le contenu du fichier
        content = self._create_markdown_content(conversation_data)

        # Écrire le fichier
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)

        return str(filepath)

    def _create_markdown_content(self, conversation_data: dict) -> str:
        """
        Créer le contenu Markdown pour une conversation.

        Args:
            conversation_data: Données de la conversation

        Returns:
            Contenu Markdown
        """
        title = conversation_data.get("title", "Conversation sans titre")
        date = conversation_data.get("date", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        participants = conversation_data.get("participants", [])
        messages = conversation_data.get("messages", [])

        # Créer l'en-tête
        content = f"""---
title: {title}
date: {date}
type: conversation
tags: #discord #conversation
---

# {title}

> **Date**: {date}
> **Participants**: {", ".join(participants)}

## 📝 Participants

"""

        # Ajouter les participants
        for participant in participants:
            content += f"- {participant}\n"

        # Ajouter les messages
        content += "\n## 💬 Messages\n\n"

        for i, message in enumerate(messages, 1):
            author = message.get("author", "Inconnu")
            text = message.get("text", "")
            timestamp = message.get("timestamp", "")

            content += f"### Message {i}\n\n"
            content += f"**Auteur**: {author}\n"
            if timestamp:
                content += f"**Heure**: {timestamp}\n"
            content += f"\n{text}\n\n"

        # Ajouter les métadonnées
        content += "---\n"
        content += f"*Enregistré automatiquement par Discord Conversation Logger*\n"
        content += f"*Date d'enregistrement: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n"

        return content

    def create_daily_summary(self, date: str = None) -> str:
        """
        Créer un résumé quotidien des conversations.

        Args:
            date: Date au format YYYY-MM-DD (défaut: aujourd'hui)

        Returns:
            Chemin du fichier créé
        """
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")

        filename = f"daily-summary-{date}.md"
        filepath = self.conversations_path / filename

        # Créer le contenu du résumé
        content = f"""---
title: Résumé Quotidien - {date}
date: {date}
type: summary
tags: #discord #summary
---

# 📊 Résumé Quotidien - {date}

> **Date**: {date}
> **Type**: Résumé des conversations

## 📈 Statistiques

- **Conversations enregistrées**: À compléter
- **Messages capturés**: À compléter
- **Participants**: À compléter

## 🔗 Conversations

À compléter avec les conversations de la journée.

## 📝 Notes

Notes importantes de la journée.

---

*Résumé créé automatiquement par Discord Conversation Logger*
"""

        # Écrire le fichier
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(content)

        return str(filepath)


def main():
    """Fonction principale pour tester le logger."""
    # Exemple d'utilisation
    vault_path = "/home/vboxuser/Documents/Obsidian Vault"
    logger = DiscordConversationLogger(vault_path)

    # Exemple de conversation
    conversation_data = {
        "title": "Test Conversation",
        "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "participants": ["User1", "User2"],
        "messages": [
            {
                "author": "User1",
                "text": "Bonjour!",
                "timestamp": "10:00:00"
            },
            {
                "author": "User2",
                "text": "Salut!",
                "timestamp": "10:01:00"
            }
        ]
    }

    # Enregistrer la conversation
    filepath = logger.log_conversation(conversation_data)
    print(f"Conversation enregistrée: {filepath}")

    # Créer un résumé quotidien
    summary_path = logger.create_daily_summary()
    print(f"Résumé créé: {summary_path}")


if __name__ == "__main__":
    main()
