---
title: DZGrievous
type: person
discord_id: DZGrievous
created: 2026-05-01
tags: #person #discord #hermes
---

# DZGrievous

## 📋 Informations

**Nom**: DZGrievous
**ID Discord**: 677139571754008576
**Rôle**: Membre principal du système Hermes
**Bot associé**: Hermes Agent (ID: 1467515473506734104)

## 🤖 Contexte Discord

### Serveur "Club des Agents"

Le serveur compte 3 personnes et 3 bots, chaque personne ayant son propre bot dédié :

| Personne | ID Discord | Bot | ID Bot |
|----------|------------|-----|--------|
| Yoshi | 725240620611928076 | Hermes Agent | 1498378724163321958 |
| Lama2000 | 941378796186128434 | Hermes Bot | 1499114789283168409 |
| DZGrievous | 677139571754008576 | Hermes Agent | 1467515473506734104 |

**Note**: Chaque personne possède son propre bot Hermes distinct.

## 🔗 Ressources Connexes

- [[Club des Agents]] - Serveur Discord
- [[Hermes Agent (DZGrievous)]] - Bot associé
- [[Communication inter-agents]] - Système de communication

---
*Créé le 1 mai 2026*
*Statut: Actif*
