<?php
    $pdo = new PDO('sqlite:db.sqlite'); // connexion à la base de données

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // active le mode d'erreur

    // Initialisation automatique des tables nécessaires si elles n'existent pas
    $pdo->exec("CREATE TABLE IF NOT EXISTS demandes_adoption (
        id_demande INTEGER PRIMARY KEY AUTOINCREMENT,
        id_animal INTEGER NOT NULL,
        id_user INTEGER NOT NULL,
        message TEXT,
        statut TEXT DEFAULT 'En attente',
        date_demande DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_animal) REFERENCES animaux(id_animal),
        FOREIGN KEY (id_user) REFERENCES utilisateurs(id_user)
    )");
?>




