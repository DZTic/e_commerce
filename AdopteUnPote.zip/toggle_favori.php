<?php
session_start();
// ============================================================
// TOGGLE_FAVORI.PHP — Ajout/Suppression d'un favori
// ============================================================
//
// RÔLE DE CE FICHIER :
//   Gérer l'ajout ou la suppression d'un animal dans les favoris
//   SANS ouvrir la fiche de l'animal. Il traite la requête POST
//   puis redirige immédiatement l'utilisateur vers la page
//   depuis laquelle il a cliqué (catalogue, index, etc.).
//
// COMMENT IL SE CONNECTE AUX AUTRES FICHIERS :
//
//   → config.php    : Pour la connexion BDD ($pdo).
//
//   → catalogue.php : Le formulaire du bouton cœur dans catalogue.php
//                     pointe vers ce fichier. Après traitement, on
//                     redirige vers catalogue.php (ou la page d'avant).
//
//   → login.php     : Si l'utilisateur n'est pas connecté, on le
//                     redirige vers login.php au lieu de traiter.
//
//   → BDD 'favoris' : Ce fichier fait uniquement un INSERT ou DELETE
//                     dans la table favoris, rien d'autre.
//
// FLUX DES DONNÉES :
//   1. Formulaire POST reçu depuis catalogue.php (ou index.php)
//   2. Vérification : utilisateur connecté ? sinon → login.php
//   3. Récupération de l'ID animal depuis $_POST['id_animal']
//   4. Vérification : déjà en favori ?
//      - Non → INSERT INTO favoris
//      - Oui  → DELETE FROM favoris (toggle = bascule)
//   5. Redirection vers la page précédente ($_POST['redirect_to'])
// ============================================================

require_once 'config.php';

// -------------------------------------------------------
// PROTECTION : l'utilisateur doit être connecté
// -------------------------------------------------------
if (!isset($_SESSION['user_id'])) {
    // On redirige vers login, puis login renverra vers catalogue
    header('Location: login.php');
    exit();
}

// -------------------------------------------------------
// VÉRIFICATION : la requête doit être en POST
// -------------------------------------------------------
// Ce fichier ne doit jamais être ouvert directement dans le navigateur
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: catalogue.php');
    exit();
}

// -------------------------------------------------------
// RÉCUPÉRATION DES DONNÉES POST
// -------------------------------------------------------
$id_user   = $_SESSION['user_id'];

// intval() protège contre les injections SQL
$id_animal = isset($_POST['id_animal']) ? intval($_POST['id_animal']) : 0;

// Page vers laquelle rediriger après l'action (catalogue, index, etc.)
// On sécurise avec htmlspecialchars pour éviter les redirections malveillantes
$redirect  = isset($_POST['redirect_to']) ? $_POST['redirect_to'] : 'catalogue.php';

// Sécurité : on n'autorise que des redirections vers des pages du site
$pages_autorisees = ['catalogue.php', 'index.php', 'liste.php', 'fiche.php'];
if (!in_array($redirect, $pages_autorisees)) {
    $redirect = 'catalogue.php';
}

// -------------------------------------------------------
// LOGIQUE TOGGLE : ajouter OU retirer des favoris
// -------------------------------------------------------
if ($id_animal > 0) {

    // On vérifie si cet animal est déjà dans les favoris de l'utilisateur
    $check = $pdo->prepare("SELECT id_favori FROM favoris WHERE id_user = ? AND id_animal = ?");
    $check->execute([$id_user, $id_animal]);
    $favori_existant = $check->fetch();

    if (!$favori_existant) {
        // L'animal N'EST PAS encore en favori → on l'AJOUTE
        $ins = $pdo->prepare("INSERT INTO favoris (id_user, id_animal) VALUES (?, ?)");
        $ins->execute([$id_user, $id_animal]);
    } else {
        // L'animal EST déjà en favori → on le RETIRE (comportement toggle)
        $del = $pdo->prepare("DELETE FROM favoris WHERE id_user = ? AND id_animal = ?");
        $del->execute([$id_user, $id_animal]);
    }
}

// -------------------------------------------------------
// REDIRECTION : retour vers la page précédente
// -------------------------------------------------------

// Cas spécial : si on vient de la fiche, on doit repasser l'ID dans l'URL
if ($redirect === 'fiche.php' && $id_animal > 0) {
    header('Location: fiche.php?id=' . $id_animal);
    exit();
}

// Sinon redirection classique (catalogue, index...)
// On utilise le paramètre 'page' pour garder la pagination active si besoin
$page_param = isset($_POST['page_param']) ? '&' . $_POST['page_param'] : '';
header('Location: ' . $redirect . '?' . $page_param);
exit();
