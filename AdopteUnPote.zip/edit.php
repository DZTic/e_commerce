<?php
session_start();
// Inclusion du fichier de configuration pour la connexion à la base de données
require_once 'config.php';

// SÉCURITÉ : Vérification des droits d'accès
// On s'assure que seul un administrateur peut accéder à cette page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); 
    exit();
}

// Vérification de la présence de l'ID de l'animal dans l'URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Si pas d'ID, on redirige vers l'administration
    header('Location: admin.php');
    exit();
}

$id_animal = (int) $_GET['id'];

// Récupération des données actuelles de l'animal pour préremplir le formulaire
$stmt = $pdo->prepare("SELECT * FROM animaux WHERE id_animal = ?");
$stmt->execute([$id_animal]);
$animal = $stmt->fetch();

// Si l'animal n'existe pas dans la base de données, on redirige
if (!$animal) {
    header('Location: admin.php');
    exit();
}

// Récupération des catégories pour le menu déroulant
$cat_query = $pdo->query("SELECT * FROM categories ORDER BY nom_cat ASC");
$categories = $cat_query->fetchAll();

// Traitement du formulaire lors de sa soumission (méthode POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et sécurisation des données envoyées par le formulaire
    $nom_animal = trim($_POST['nom_animal']);
    $id_cat = (int) $_POST['id_cat'];
    $description = trim($_POST['description']);
    $statut = trim($_POST['statut']);
    $age = trim($_POST['age']);
    $genre = trim($_POST['genre']);
    $taille = trim($_POST['taille']);
    
    // Par défaut, on garde l'ancienne image
    $image = $animal['image'];

    // Gestion de l'upload d'une nouvelle image (si fournie)
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'img/';
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_name = $_FILES['image']['name'];
        // On génère un nom unique pour éviter d'écraser des fichiers existants
        $new_file_name = uniqid() . '_' . basename($file_name);
        $destination = $upload_dir . $new_file_name;

        // On déplace le fichier téléchargé vers le dossier d'images
        if (move_uploaded_file($file_tmp, $destination)) {
            $image = $new_file_name; // Mise à jour du nom de l'image pour la BDD
        }
    }

    // Mise à jour des informations de l'animal dans la base de données
    $update_stmt = $pdo->prepare("
        UPDATE animaux 
        SET nom_animal = ?, id_cat = ?, description = ?, statut = ?, age = ?, genre = ?, taille = ?, image = ? 
        WHERE id_animal = ?
    ");
    
    $update_stmt->execute([
        $nom_animal, 
        $id_cat, 
        $description, 
        $statut, 
        $age, 
        $genre, 
        $taille, 
        $image, 
        $id_animal
    ]);

    // Redirection vers la page d'administration après la modification réussie
    header('Location: admin.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier un animal - AdopteUnPote</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .container-admin {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 1rem;
        }
        .form-group select, .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            font-size: 1rem;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        .current-image {
            margin-bottom: 1rem;
        }
        .current-image img {
            max-width: 150px;
            border-radius: var(--radius);
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">🐾 Admin - AdopteUnPote</div>
        <nav>
            <a href="admin.php">Retour à l'administration</a>
        </nav>
    </header>

    <main class="container-admin">
        <h1>Modifier l'animal : <?= htmlspecialchars($animal['nom_animal']) ?></h1>

        <!-- Formulaire de modification. 'enctype' est nécessaire pour l'upload de fichiers -->
        <form class="auth-form" method="POST" action="edit.php?id=<?= $id_animal ?>" enctype="multipart/form-data">
            
            <div class="form-group">
                <label for="nom_animal">Nom de l'animal :</label>
                <!-- L'attribut value est prérempli avec la donnée existante (sécurisée par htmlspecialchars) -->
                <input type="text" id="nom_animal" name="nom_animal" value="<?= htmlspecialchars($animal['nom_animal']) ?>" required>
            </div>

            <div class="form-group">
                <label for="id_cat">Catégorie :</label>
                <select id="id_cat" name="id_cat" required>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?= $cat['id_cat'] ?>" <?= ($cat['id_cat'] == $animal['id_cat']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['nom_cat']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="statut">Statut :</label>
                <select id="statut" name="statut" required>
                    <option value="disponible" <?= ($animal['statut'] === 'disponible') ? 'selected' : '' ?>>Disponible</option>
                    <option value="adopté" <?= ($animal['statut'] === 'adopté') ? 'selected' : '' ?>>Adopté</option>
                    <option value="réservé" <?= ($animal['statut'] === 'réservé') ? 'selected' : '' ?>>Réservé</option>
                </select>
            </div>

            <div class="form-group">
                <label for="age">Âge :</label>
                <input type="text" id="age" name="age" value="<?= htmlspecialchars($animal['age']) ?>">
            </div>

            <div class="form-group">
                <label for="genre">Genre :</label>
                <select id="genre" name="genre">
                    <option value="male" <?= ($animal['genre'] === 'male') ? 'selected' : '' ?>>Mâle</option>
                    <option value="femelle" <?= ($animal['genre'] === 'femelle') ? 'selected' : '' ?>>Femelle</option>
                    <option value="inconnu" <?= ($animal['genre'] === 'inconnu') ? 'selected' : '' ?>>Inconnu</option>
                </select>
            </div>

            <div class="form-group">
                <label for="taille">Taille :</label>
                <select id="taille" name="taille">
                    <option value="petit" <?= ($animal['taille'] === 'petit') ? 'selected' : '' ?>>Petit</option>
                    <option value="moyen" <?= ($animal['taille'] === 'moyen') ? 'selected' : '' ?>>Moyen</option>
                    <option value="grand" <?= ($animal['taille'] === 'grand') ? 'selected' : '' ?>>Grand</option>
                </select>
            </div>

            <div class="form-group">
                <label for="description">Description :</label>
                <!-- Les textarea ne prennent pas l'attribut value, le contenu va entre les balises -->
                <textarea id="description" name="description"><?= htmlspecialchars($animal['description']) ?></textarea>
            </div>

            <div class="form-group">
                <label>Image actuelle :</label>
                <div class="current-image">
                    <img src="img/<?= htmlspecialchars($animal['image']) ?>" alt="Photo de <?= htmlspecialchars($animal['nom_animal']) ?>">
                </div>
                <label for="image">Remplacer l'image (laisser vide pour conserver l'actuelle) :</label>
                <input type="file" id="image" name="image" accept="image/*">
            </div>

            <button type="submit" class="btn-submit">Enregistrer les modifications</button>
        </form>
    </main>
</body>
</html>
