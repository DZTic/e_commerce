<?php
require 'config.php';

try {
    // Création de la table demandes_adoption
    $pdo->exec("CREATE TABLE IF NOT EXISTS demandes_adoption (
        id_demande INTEGER PRIMARY KEY AUTOINCREMENT,
        id_animal INTEGER NOT NULL,
        id_user INTEGER NOT NULL,
        message TEXT,
        statut TEXT DEFAULT 'En attente',
        date_demande DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_animal) REFERENCES animaux(id_animal),
        FOREIGN KEY (id_user) REFERENCES utilisateurs(id_user)
    )");
    
    // Ajout de colonnes manquantes potentielles pour les rôles si nécessaire
    // (Mais on a vu que role est déjà utilisé)
    
    echo "Table demandes_adoption créée avec succès.";
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}
?>
