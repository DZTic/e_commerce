<?php
// Inclusion du fichier de configuration pour se connecter à la base de données
require_once 'config.php';

// Vérification de la présence du paramètre 'id' dans l'URL (méthode GET)
// Cela signifie que l'on veut supprimer l'animal correspondant à cet ID.
if (isset($_GET['id'])) {
    // intval() permet de s'assurer que l'ID est bien un nombre entier.
    // C'est une sécurité supplémentaire contre les injections SQL (bien que prepare le fasse déjà).
    $id = intval($_GET['id']);
    
    // On utilise prepare() au lieu de query() pour sécuriser la requête contre les injections SQL.
    // Le '?' est un marqueur qui sera remplacé par la valeur de l'ID lors de l'exécution.
    $query = $pdo->prepare("DELETE FROM animaux WHERE id_animal = ?");
    
    // On exécute la requête préparée en lui passant le tableau des paramètres (ici l'ID).
    // Cette commande va supprimer définitivement l'enregistrement de la base de données.
    $query->execute([$id]);
}

// Une fois la suppression effectuée (ou si aucun ID n'était fourni),
// on redirige l'utilisateur vers la page d'administration.
header('Location: admin.php');
exit(); // On arrête le script pour s'assurer que la redirection se fait correctement.