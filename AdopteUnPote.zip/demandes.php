<?php
/**
 * DEMANDES.PHP — Interface de gestion des demandes d'adoption
 */

session_start();
require_once 'config.php';

// SÉCURITÉ : Accessible uniquement aux Admins et Gestionnaires
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'gestionnaire')) {
    header('Location: index.php');
    exit();
}

// TRAITEMENT DU CHANGEMENT DE STATUT
if (isset($_POST['id_demande']) && isset($_POST['nouveau_statut'])) {
    $id_demande = intval($_POST['id_demande']);
    $nouveau_statut = $_POST['nouveau_statut']; // 'Validée' ou 'Refusée'
    
    // Commencer une transaction pour s'assurer que les deux tables sont mises à jour
    $pdo->beginTransaction();
    try {
        // Mettre à jour la demande
        $stmt = $pdo->prepare("UPDATE demandes_adoption SET statut = ? WHERE id_demande = ?");
        $stmt->execute([$nouveau_statut, $id_demande]);
        
        // Si validée, mettre l'animal en statut 'Adopté'
        if ($nouveau_statut === 'Validée') {
            $stmt_get_animal = $pdo->prepare("SELECT id_animal FROM demandes_adoption WHERE id_demande = ?");
            $stmt_get_animal->execute([$id_demande]);
            $id_animal = $stmt_get_animal->fetchColumn();
            
            $stmt_update_animal = $pdo->prepare("UPDATE animaux SET statut = 'Adopté' WHERE id_animal = ?");
            $stmt_update_animal->execute([$id_animal]);
        }
        
        $pdo->commit();
        $success_msg = "La demande a été " . strtolower($nouveau_statut) . " avec succès.";
    } catch (Exception $e) {
        $pdo->rollBack();
        $error_msg = "Erreur lors de la mise à jour : " . $e->getMessage();
    }
}

// RÉCUPÉRATION DES DEMANDES
$query = $pdo->query("
    SELECT d.*, a.nom_animal, a.image, u.login 
    FROM demandes_adoption d
    JOIN animaux a ON d.id_animal = a.id_animal
    JOIN utilisateurs u ON d.id_user = u.id_user
    ORDER BY d.date_demande DESC
");
$demandes = $query->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion des Demandes - AdopteUnPote</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .demandes-main { padding: 40px 50px; background: #f4f7f9; min-height: 80vh; }
        .demandes-table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        .demandes-table th, .demandes-table td { padding: 15px; text-align: left; border-bottom: 1px solid #eee; }
        .demandes-table th { background: #479354; color: white; }
        .status-badge { padding: 5px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: bold; }
        .status-en-attente { background: #fff3cd; color: #856404; }
        .status-validee { background: #d4edda; color: #155724; }
        .status-refusee { background: #f8d7da; color: #721c24; }
        .btn-action { padding: 5px 10px; border: none; border-radius: 5px; cursor: pointer; font-size: 0.8rem; transition: 0.2s; }
        .btn-valider { background: #479354; color: white; }
        .btn-refuser { background: #e53935; color: white; }
        .btn-action:hover { opacity: 0.8; transform: scale(1.05); }
        .animal-thumb { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; vertical-align: middle; margin-right: 10px; }
    </style>
</head>
<body>
    <header>
        <div class="logo">🐾 Gestion - AdopteUnPote</div>
        <nav>
            <a href="index.php">Retour au site</a>
            <?php if ($_SESSION['role'] === 'admin'): ?>
                <a href="admin.php">Administration</a>
            <?php endif; ?>
            <a href="demandes.php" style="font-weight: bold; color: #479354;">Demandes</a>
            <a href="logout.php" style="color: #d32f2f;">Déconnexion</a>
        </nav>
    </header>

    <main class="demandes-main">
        <h1>Demandes d'Adoption</h1>
        
        <?php if (isset($success_msg)): ?>
            <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #c3e6cb;"><?= $success_msg ?></div>
        <?php endif; ?>
        
        <?php if (isset($error_msg)): ?>
            <div style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb;"><?= $error_msg ?></div>
        <?php endif; ?>

        <table class="demandes-table">
            <thead>
                <tr>
                    <th>Animal</th>
                    <th>Utilisateur</th>
                    <th>Date</th>
                    <th>Message</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($demandes as $d): ?>
                    <tr>
                        <td>
                            <img src="img/<?= htmlspecialchars($d['image']) ?>" class="animal-thumb">
                            <?= htmlspecialchars($d['nom_animal']) ?>
                        </td>
                        <td><?= htmlspecialchars($d['login']) ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($d['date_demande'])) ?></td>
                        <td><small><?= nl2br(htmlspecialchars($d['message'])) ?></small></td>
                        <td>
                            <?php 
                            $badge_class = 'status-en-attente';
                            $display_statut = $d['statut'];
                            if ($d['statut'] === 'Validée') { $badge_class = 'status-validee'; }
                            if ($d['statut'] === 'Refusée') { $badge_class = 'status-refusee'; }
                            if ($d['statut'] === 'en_attente') { $display_statut = 'En attente'; }
                            ?>
                            <span class="status-badge <?= $badge_class ?>">
                                <?= htmlspecialchars($display_statut) ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($d['statut'] === 'en_attente'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="id_demande" value="<?= $d['id_demande'] ?>">
                                    <button type="submit" name="nouveau_statut" value="Validée" class="btn-action btn-valider">Valider</button>
                                    <button type="submit" name="nouveau_statut" value="Refusée" class="btn-action btn-refuser">Refuser</button>
                                </form>
                            <?php else: ?>
                                <span style="color: #999; font-size: 0.8rem;">Traitée</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>© 2026 AdopteUnPote - Gestionnaire</p>
    </footer>
</body>
</html>
