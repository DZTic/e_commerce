<?php
/**
 * TRAITER_DEMANDE.PHP — Traitement de la demande d'adoption
 */

session_start();
require_once 'config.php';

// Vérification de la connexion
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_animal = intval($_POST['id_animal']);
    $id_user   = $_SESSION['user_id'];
    $message   = trim($_POST['message']);

    // Vérifier si une demande existe déjà pour cet utilisateur et cet animal
    $check = $pdo->prepare("SELECT id_demande FROM demandes_adoption WHERE id_animal = ? AND id_user = ? AND statut = 'En attente'");
    $check->execute([$id_animal, $id_user]);

    if ($check->fetch()) {
        header("Location: fiche.php?id=$id_animal&error=Vous avez déjà une demande en attente pour cet animal.");
        exit();
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO demandes_adoption (id_animal, id_user, message) VALUES (?, ?, ?)");
        $stmt->execute([$id_animal, $id_user, $message]);
        
        header("Location: fiche.php?id=$id_animal&success=Votre demande d'adoption a bien été envoyée !");
    } catch (PDOException $e) {
        header("Location: fiche.php?id=$id_animal&error=Une erreur est survenue lors de l'envoi de votre demande.");
    }
} else {
    header('Location: catalogue.php');
}
?>
