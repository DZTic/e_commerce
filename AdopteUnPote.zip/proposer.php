<?php
/**
 * PROPOSER.PHP — Page de soumission d'un nouvel animal
 * 
 * RÔLE :
 * Permettre aux utilisateurs de proposer un animal à l'adoption.
 * Gère l'upload de l'image et l'insertion en base de données.
 */

session_start();
require_once 'config.php';

// 1. VÉRIFICATION DE LA CONNEXION
// On peut choisir d'autoriser tout le monde ou seulement les connectés.
// Ici, on redirige vers login.php si l'utilisateur n'est pas connecté.
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Initialisation des variables pour les messages
$success = "";
$error = "";

// 2. RÉCUPÉRATION DES CATÉGORIES POUR LE FORMULAIRE
// On en a besoin pour remplir le <select> du formulaire.
try {
    $stmt_cat = $pdo->query("SELECT * FROM categories ORDER BY nom_cat ASC");
    $categories = $stmt_cat->fetchAll();
} catch (PDOException $e) {
    $error = "Erreur lors de la récupération des catégories : " . $e->getMessage();
}

// 3. TRAITEMENT DU FORMULAIRE (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et nettoyage des données
    $nom_animal  = trim($_POST['nom_animal']);
    $id_cat      = intval($_POST['id_cat']);
    $age         = trim($_POST['age']);
    $genre       = $_POST['genre'];
    $taille      = $_POST['taille'];
    $description = trim($_POST['description']);
    
    // Validation simple
    if (empty($nom_animal) || empty($id_cat) || empty($age) || empty($description)) {
        $error = "Veuillez remplir tous les champs obligatoires.";
    } else {
        // GESTION DE L'IMAGE
        $image_name = "default.jpg"; // Image par défaut si aucune n'est fournie
        
        if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'webp'];
            $file_info = pathinfo($_FILES['image']['name']);
            $extension = strtolower($file_info['extension']);
            
            if (in_array($extension, $allowed_extensions)) {
                // On crée un nom unique pour éviter les doublons (ex: 1672531200_chien.jpg)
                $image_name = time() . "_" . preg_replace('/[^a-z0-9]/', '', strtolower($nom_animal)) . "." . $extension;
                $target_path = "img/" . $image_name;
                
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
                    $error = "Erreur lors de l'upload de l'image.";
                    $image_name = "default.jpg"; // On repasse sur le défaut en cas d'échec
                }
            } else {
                $error = "Format d'image non supporté (JPG, PNG, WEBP uniquement).";
            }
        }

        // Si aucune erreur jusqu'ici, on insère en base de données
        if (empty($error)) {
            try {
                $sql = "INSERT INTO animaux (nom_animal, id_cat, age, genre, taille, description, image, statut, date_ajout) 
                        VALUES (:nom, :id_cat, :age, :genre, :taille, :description, :image, 'disponible', datetime('now'))";
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':nom'         => $nom_animal,
                    ':id_cat'      => $id_cat,
                    ':age'         => $age,
                    ':genre'       => $genre,
                    ':taille'      => $taille,
                    ':description' => $description,
                    ':image'       => $image_name
                ]);
                
                $success = "L'animal a été proposé avec succès ! Il est maintenant visible dans le catalogue.";
            } catch (PDOException $e) {
                $error = "Erreur lors de l'enregistrement : " . $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proposer un animal - AdopteUnPote</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- HEADER RÉUTILISÉ -->
    <header>
        <div class="logo">🐾 AdopteUnPote</div>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="catalogue.php">Animaux</a>
            <a href="proposer.php" class="nav-active">Proposer un animal</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'gestionnaire'): ?>
                    <a href="<?= $_SESSION['role'] === 'admin' ? 'admin.php' : 'demandes.php' ?>">Administration</a>
                <?php endif; ?>
                <a href="mes_demandes.php">Mes Demandes</a>
                <a href="favoris.php">Mes Favoris ❤️</a>
                <a href="logout.php" style="color: #d32f2f; font-weight: bold;">Se déconnecter</a>
            <?php else: ?>
                <a href="login.php">Connexion/Inscription</a>
            <?php endif; ?>
        </nav>
    </header>

    <main class="proposer-main">
        <div class="form-container">
            <div class="form-header">
                <h1>Proposer un animal</h1>
                <p>Aidez un animal à trouver un nouveau foyer chaleureux.</p>
            </div>

            <!-- Affichage des messages de succès ou d'erreur -->
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="alert alert-error"><?= $error ?></div>
            <?php endif; ?>

            <!-- FORMULAIRE DE SOUMISSION -->
            <!-- Notez l'attribut enctype="multipart/form-data" indispensable pour l'upload d'images -->
            <form action="proposer.php" method="POST" enctype="multipart/form-data">
                <div class="form-grid">
                    
                    <!-- Nom de l'animal -->
                    <div class="form-group full-width">
                        <label for="nom_animal">Nom de l'animal *</label>
                        <input type="text" name="nom_animal" id="nom_animal" placeholder="Ex: Rex, Luna..." required>
                    </div>

                    <!-- Catégorie -->
                    <div class="form-group">
                        <label for="id_cat">Catégorie *</label>
                        <select name="id_cat" id="id_cat" required>
                            <option value="">-- Choisir --</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id_cat'] ?>"><?= htmlspecialchars($cat['nom_cat']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- Âge -->
                    <div class="form-group">
                        <label for="age">Âge (ex: 2 ans, 6 mois) *</label>
                        <input type="text" name="age" id="age" placeholder="Ex: 3 ans" required>
                    </div>

                    <!-- Genre -->
                    <div class="form-group">
                        <label>Genre *</label>
                        <div class="radio-options">
                            <label><input type="radio" name="genre" value="male" checked> Mâle</label>
                            <label><input type="radio" name="genre" value="femelle"> Femelle</label>
                        </div>
                    </div>

                    <!-- Taille -->
                    <div class="form-group">
                        <label for="taille">Taille *</label>
                        <select name="taille" id="taille" required>
                            <option value="petit">Petit</option>
                            <option value="moyen" selected>Moyen</option>
                            <option value="grand">Grand</option>
                        </select>
                    </div>

                    <!-- Histoire / Description -->
                    <div class="form-group full-width">
                        <label for="description">Son histoire / Description *</label>
                        <textarea name="description" id="description" placeholder="Racontez-nous son parcours, son caractère..." required></textarea>
                    </div>

                    <!-- Photo -->
                    <div class="form-group full-width">
                        <label for="image">Photo de l'animal</label>
                        <input type="file" name="image" id="image" accept="image/*">
                        <small style="color: #888;">Formats acceptés : JPG, PNG, WEBP. Laissez vide pour une image par défaut.</small>
                    </div>

                </div>

                <button type="submit" class="btn-submit-proposer">Soumettre la proposition</button>
            </form>
        </div>
    </main>

    <!-- FOOTER RÉUTILISÉ -->
    <footer>
        <p><a href="#">Contact</a> | <a href="#">Mentions Légales</a> | <a href="#">Réseaux Sociaux</a></p>
        <p>© 2026 AdopteUnPote</p>
    </footer>

</body>
</html>
