<?php
session_start();
// ============================================================
// FICHE.PHP — Page de détail d'un animal
// ============================================================
//
// RÔLE DE CE FICHIER :
//   Affiche toutes les informations d'UN seul animal.
//   L'animal est identifié par son ID passé dans l'URL.
//   Exemple d'URL : fiche.php?id=3  →  affiche l'animal n°3.
//
// COMMENT IL SE CONNECTE AUX AUTRES FICHIERS :
//
//   → config.php    : Inclus via require_once pour la connexion
//                     à la base de données SQLite ($pdo).
//
//   → catalogue.php : C'est depuis catalogue.php (et index.php)
//                     que l'on arrive ici via les liens "Voir plus".
//                     Si l'ID passé est invalide, on redirige vers
//                     catalogue.php.
//
//   → toggle_favori.php : Le bouton "Ajouter aux favoris" soumet
//                     un formulaire POST vers toggle_favori.php,
//                     qui gère l'ajout en BDD et redirige ici.
//
//   → login.php     : Si l'utilisateur clique sur "Ajouter aux
//                     favoris" SANS être connecté (pas de session),
//                     toggle_favori.php le redirige vers login.php.
//
//   → style.css     : Les classes .page-fiche, .fiche-wrapper,
//                     .fiche-card-img, .fiche-card-info, .badge-cat,
//                     .btn-adopt, .btn-fav définissent le rendu.
//
// FLUX DES DONNÉES :
//   1. Arrivée depuis catalogue.php avec ?id=X dans l'URL
//   2. PHP lit $_GET['id'] et sécurise avec intval()
//   3. Requête SQL préparée (protection injection SQL) pour
//      récupérer les infos de cet animal + sa catégorie (JOIN)
//   4. Si l'animal n'existe pas → redirection catalogue.php
//   5. Vérification si l'animal est déjà en favori (si connecté)
//   6. Affichage de la fiche avec image, description, statut
// ============================================================

require_once 'config.php';

// -------------------------------------------------------
// ÉTAPE 1 : Récupérer l'ID de l'animal passé dans l'URL
// -------------------------------------------------------
// intval() convertit en entier entier pour éviter les injections SQL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// -------------------------------------------------------
// ÉTAPE 2 : Requête SQL pour récupérer les infos de l'animal
// -------------------------------------------------------
// On utilise une requête préparée avec le paramètre :id pour la sécurité
// Le JOIN permet de récupérer le nom de la catégorie (table categories)
// en plus des infos de l'animal (table animaux)
$query = $pdo->prepare("
    SELECT a.*, c.nom_cat
    FROM animaux a
    JOIN categories c ON a.id_cat = c.id_cat
    WHERE a.id_animal = :id
");
$query->execute(['id' => $id]);
$animal = $query->fetch();

// -------------------------------------------------------
// ÉTAPE 3 : Vérification — si l'animal n'existe pas
// -------------------------------------------------------
// Si l'ID est invalide ou l'animal introuvable, on redirige vers le catalogue
if (!$animal) {
    header('Location: catalogue.php');
    exit();
}

// -------------------------------------------------------
// ÉTAPE 4 : Vérifier si cet animal est déjà en favori
// -------------------------------------------------------
// On ne vérifie que si l'utilisateur est connecté (session active)
$est_en_favori = false;
if (isset($_SESSION['user_id'])) {
    $id_user   = $_SESSION['user_id'];
    $check_fav = $pdo->prepare("SELECT id_favori FROM favoris WHERE id_user = ? AND id_animal = ?");
    $check_fav->execute([$id_user, $id]);
    
    // fetch() est plus fiable que rowCount() pour les SELECT en SQLite
    if ($check_fav->fetch()) {
        $est_en_favori = true;
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Fiche de <?= htmlspecialchars($animal['nom_animal']) ?> - AdopteUnPote</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="page-fiche">

    <!-- ===== HEADER ===== -->
    <header>
        <div class="logo">🐾 AdopteUnPote</div>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="catalogue.php">Animaux</a>
            <a href="proposer.php">Proposer un animal</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'gestionnaire'): ?>
                    <a href="<?= $_SESSION['role'] === 'admin' ? 'admin.php' : 'demandes.php' ?>">Administration</a>
                <?php endif; ?>
                <a href="mes_demandes.php">Mes Demandes</a>
                <a href="favoris.php">Mes Favoris ❤️</a>
                <a href="logout.php" style="color: #d32f2f; font-weight: bold;">Se déconnecter</a>
            <?php else: ?>
                <a href="login.php">Connexion/Inscription</a>
            <?php endif; ?>
        </nav>
    </header>

    <!-- ===== CONTENU PRINCIPAL ===== -->
    <div class="fiche-wrapper">

        <!-- Affichage des messages de succès ou d'erreur -->
        <?php if (isset($_GET['success'])): ?>
            <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #c3e6cb; text-align: center;">
                <?= htmlspecialchars($_GET['success']) ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_GET['error'])): ?>
            <div style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #f5c6cb; text-align: center;">
                <?= htmlspecialchars($_GET['error']) ?>
            </div>
        <?php endif; ?>

        <!-- Titre de la page avec le nom de l'animal -->
        <h1 class="fiche-title">Fiche de <?= htmlspecialchars($animal['nom_animal']) ?></h1>

        <!-- Layout deux cartes côte à côte -->
        <div class="fiche-layout">

            <!-- CARTE GAUCHE : Image de l'animal -->
            <div class="fiche-card-img">
                <img src="img/<?= htmlspecialchars($animal['image']) ?>"
                     alt="<?= htmlspecialchars($animal['nom_animal']) ?>">
            </div>

            <!-- CARTE DROITE : Informations détaillées -->
            <div class="fiche-card-info">

                <!-- Badge catégorie (ex : Chien, Chat...) -->
                <!-- Affiché en vert pour indiquer visuellement le type d'animal -->
                <span class="badge-cat"><?= htmlspecialchars($animal['nom_cat']) ?></span>

                <!-- Nom de l'animal en très grand -->
                <h2 class="fiche-nom"><?= htmlspecialchars($animal['nom_animal']) ?></h2>

                <!-- Statut de l'animal (disponible, adopté...) -->
                <p class="fiche-statut">
                    Statut : <strong><?= htmlspecialchars($animal['statut']) ?></strong>
                </p>

                <hr class="fiche-divider">

                <!-- Description : histoire de l'animal -->
                <!-- nl2br() convertit les sauts de ligne du texte BDD en <br> HTML -->
                <h3 class="fiche-section-title">Sa petite histoire</h3>
                <p class="fiche-description">
                    <?= nl2br(htmlspecialchars($animal['description'])) ?>
                </p>

                    <!-- BOUTONS D'ACTION -->
                <div class="fiche-buttons">

                    <!-- Bouton principal : demande d'adoption (ouvre un formulaire ou soumet) -->
                    <?php if ($animal['statut'] === 'Adopté'): ?>
                        <div style="background: #e8f5e9; color: #2e7d32; padding: 20px; border-radius: 10px; border: 1px solid #c8e6c9; margin-top: 20px; text-align: center; font-weight: bold;">
                            🎉 Cet animal a trouvé sa famille pour la vie !
                        </div>
                    <?php elseif (isset($_SESSION['user_id'])): ?>
                        <?php
                        // Vérifier si l'utilisateur a déjà une demande en attente
                        $check_demande = $pdo->prepare("SELECT statut FROM demandes_adoption WHERE id_animal = ? AND id_user = ? ORDER BY date_demande DESC LIMIT 1");
                        $check_demande->execute([$animal['id_animal'], $_SESSION['user_id']]);
                        $demande_existante = $check_demande->fetch();
                        ?>

                        <?php if ($demande_existante && $demande_existante['statut'] === 'en_attente'): ?>
                            <div style="background: #fff3cd; color: #856404; padding: 20px; border-radius: 10px; border: 1px solid #ffeeba; margin-top: 20px; text-align: center;">
                                ⏳ Votre demande d'adoption est en cours de traitement par nos équipes.
                            </div>
                        <?php elseif ($demande_existante && $demande_existante['statut'] === 'Validée'): ?>
                            <div style="background: #d4edda; color: #155724; padding: 20px; border-radius: 10px; border: 1px solid #c3e6cb; margin-top: 20px; text-align: center;">
                                ✅ Félicitations ! Votre demande d'adoption a été acceptée.
                            </div>
                        <?php else: ?>
                            <div class="adoption-form-container" style="margin-top: 20px; background: #f9f9f9; padding: 20px; border-radius: 10px; border: 1px solid #eee;">
                                <h3 style="margin-top: 0;">Envoyer une demande d'adoption</h3>
                                <form action="traiter_demande.php" method="POST">
                                    <input type="hidden" name="id_animal" value="<?= $animal['id_animal'] ?>">
                                    <div class="form-group" style="margin-bottom: 15px;">
                                        <label for="message" style="display: block; margin-bottom: 5px; font-weight: bold;">Votre message (facultatif) :</label>
                                        <textarea name="message" id="message" rows="3" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; resize: vertical;" placeholder="Pourquoi souhaitez-vous adopter cet animal ?"></textarea>
                                    </div>
                                    <button type="submit" class="btn-adopt" style="width: 100%; border: none; cursor: pointer;">Confirmer ma demande</button>
                                </form>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="login.php" class="btn-adopt" style="text-align: center; text-decoration: none; display: block;">Connectez-vous pour adopter</a>
                    <?php endif; ?>

                    <!-- Bouton favori : soumet vers toggle_favori.php -->
                    <!-- toggle_favori.php gère l'ajout/suppression et redirige ici -->
                    <form method="POST" action="toggle_favori.php" class="fiche-fav-form">
                        <!-- ID de l'animal concerné -->
                        <input type="hidden" name="id_animal" value="<?= $animal['id_animal'] ?>">
                        <!-- Page de retour : on reste sur la fiche après l'action -->
                        <input type="hidden" name="redirect_to" value="fiche.php">
                        
                        <?php if ($est_en_favori): ?>
                            <!-- L'animal est déjà en favori : bouton rouge plein -->
                            <button type="submit" class="btn-fav btn-fav-active">
                                Retirer des favoris ♥
                            </button>
                        <?php else: ?>
                            <!-- L'animal n'est pas en favori : bouton contour rouge -->
                            <button type="submit" class="btn-fav">
                                Ajouter aux favoris ♡
                            </button>
                        <?php endif; ?>
                    </form>

                </div>

                <!-- Lien retour vers le catalogue -->
                <a href="catalogue.php" class="btn-retour">← Retour au catalogue</a>

            </div>
        </div>
    </div>

    <!-- ===== FOOTER ===== -->
    <footer>
        <p><a href="#">Contact</a> | <a href="#">Mentions Légales</a> | <a href="#">Réseaux Sociaux</a></p>
        <p>© 2026 AdopteUnPote</p>
    </footer>

</body>
</html>
