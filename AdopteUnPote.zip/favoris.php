<?php
session_start();
// ============================================================
// FAVORIS.PHP — Page "Mes Animaux Coup de Cœur"
// ============================================================
//
// RÔLE DE CE FICHIER :
//   Affiche la liste personnelle des animaux mis en favoris
//   par l'utilisateur connecté. Permet aussi d'écrire un
//   commentaire personnel sur chaque animal mis en favori,
//   et de retirer un animal de la liste.
//
// COMMENT IL SE CONNECTE AUX AUTRES FICHIERS :
//
//   → config.php    : Inclus via require_once. Fournit $pdo pour
//                     toutes les interactions avec la BDD SQLite.
//
//   → login.php     : Cette page est PROTÉGÉE. Si l'utilisateur
//                     n'est pas connecté (pas de $_SESSION['user_id']),
//                     il est immédiatement redirigé vers login.php.
//                     C'est la 1ère chose que ce fichier vérifie.
//
//   → fiche.php     : Les favoris sont AJOUTÉS depuis fiche.php
//                     (bouton "Ajouter aux favoris"). Cette page
//                     les LIT depuis la BDD. Chaque carte favori
//                     contient un lien "Voir la fiche" → fiche.php.
//
//   → catalogue.php : Si la liste de favoris est vide, un lien
//                     renvoie vers catalogue.php pour inciter
//                     l'utilisateur à parcourir les animaux.
//
//   → style.css     : Les classes .container, .grid-favoris,
//                     .card-favori, .textarea-comm, .btn-save-comm
//                     et .btn-remove-fav définissent le design.
//
// STRUCTURE DE LA TABLE 'favoris' EN BDD :
//   id_favori        → Identifiant unique (auto-incrémenté)
//   id_user          → Qui a mis en favori (lié à 'utilisateurs')
//   id_animal        → Quel animal (lié à 'animaux')
//   commentaire_perso→ Le texte personnel de l'utilisateur
//
// FLUX DES DONNÉES :
//   1. Vérification session → redirection login si non connecté
//   2. Si POST 'supprimer_favori' → DELETE en BDD + redirection
//   3. Si POST 'mon_comm'        → UPDATE commentaire + redirection
//   4. Requête SELECT avec JOIN animaux+favoris pour afficher
//      uniquement les favoris de CET utilisateur
//   5. Affichage en grille avec formulaires de commentaire
// ============================================================

require_once 'config.php';

// -------------------------------------------------------
// PROTECTION : page réservée aux utilisateurs connectés
// -------------------------------------------------------
// Si l'utilisateur n'est pas connecté, on le redirige vers le login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// On récupère l'ID de l'utilisateur connecté depuis la session
$id_user = $_SESSION['user_id'];

// -------------------------------------------------------
// GESTION DE LA SUPPRESSION D'UN FAVORI
// -------------------------------------------------------
if (isset($_POST['supprimer_favori'])) {
    $id_animal_sup = (int)$_POST['id_animal'];
    $del = $pdo->prepare("DELETE FROM favoris WHERE id_user = ? AND id_animal = ?");
    $del->execute([$id_user, $id_animal_sup]);
    // On recharge la page pour rafraîchir la liste
    header('Location: favoris.php');
    exit();
}

// -------------------------------------------------------
// GESTION DE LA MISE À JOUR DU COMMENTAIRE PERSONNEL
// -------------------------------------------------------
if (isset($_POST['mon_comm']) && isset($_POST['id_animal'])) {
    $id_animal_comm = (int)$_POST['id_animal'];
    $commentaire = htmlspecialchars(trim($_POST['mon_comm']));

    // On met à jour le commentaire dans la table favoris
    $upd = $pdo->prepare("UPDATE favoris SET commentaire_perso = ? WHERE id_user = ? AND id_animal = ?");
    $upd->execute([$commentaire, $id_user, $id_animal_comm]);

    // Redirection pour éviter la re-soumission du formulaire
    header('Location: favoris.php');
    exit();
}

// -------------------------------------------------------
// RÉCUPÉRER LES FAVORIS DE L'UTILISATEUR
// -------------------------------------------------------
// On joint la table animaux ET favoris pour récupérer les infos + commentaire perso
$sql = "SELECT a.*, f.commentaire_perso 
        FROM animaux a 
        JOIN favoris f ON a.id_animal = f.id_animal 
        WHERE f.id_user = ?
        ORDER BY f.id_favori DESC";
$query = $pdo->prepare($sql);
$query->execute([$id_user]);
$mes_favoris = $query->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Favoris - AdopteUnPote</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- HEADER : Navigation -->
    <header>
        <div class="logo">🐾 AdopteUnPote</div>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="catalogue.php">Animaux</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'gestionnaire'): ?>
                    <a href="<?= $_SESSION['role'] === 'admin' ? 'admin.php' : 'demandes.php' ?>">Administration</a>
                <?php endif; ?>
                <a href="mes_demandes.php">Mes Demandes</a>
                <a href="favoris.php" style="font-weight: bold; color: #479354;">Mes Favoris ❤️</a>
                <a href="logout.php" style="color: #d32f2f; font-weight: bold;">Se déconnecter</a>
            <?php else: ?>
                <a href="login.php">Connexion/Inscription</a>
            <?php endif; ?>
        </nav>
    </header>

    <!-- CONTENU PRINCIPAL -->
    <main class="container">
        <h1>❤️ Mes Animaux Coup de Cœur</h1>

        <?php if (empty($mes_favoris)): ?>
            <!-- Message si la liste est vide -->
            <div class="favoris-empty">
                <p>Vous n'avez pas encore de favoris.</p>
                <a href="catalogue.php" class="btn-card">Parcourir les animaux</a>
            </div>
        <?php else: ?>
            <!-- GRILLE DES FAVORIS avec cards enrichies -->
            <div class="grid-favoris">
                <?php foreach ($mes_favoris as $fav): ?>

                    <!-- CARTE FAVORI : contient image + infos + formulaire de commentaire -->
                    <div class="card-favori">

                        <!-- Image de l'animal -->
                        <div class="favori-img-container">
                            <img src="img/<?= htmlspecialchars($fav['image']) ?>" 
                                 alt="<?= htmlspecialchars($fav['nom_animal']) ?>">
                        </div>

                        <!-- Infos de l'animal -->
                        <div class="favori-body">
                            <h3><?= htmlspecialchars($fav['nom_animal']) ?></h3>
                            <a href="fiche.php?id=<?= $fav['id_animal'] ?>" class="btn-card">Voir la fiche</a>

                            <hr style="margin: 15px 0;">

                            <!-- FORMULAIRE DE COMMENTAIRE PERSONNEL -->
                            <!-- Permet d'ajouter une note perso sur cet animal (stockée en BDD) -->
                            <form method="POST" action="favoris.php">
                                <!-- Champ caché pour identifier quel animal on commente -->
                                <input type="hidden" name="id_animal" value="<?= $fav['id_animal'] ?>">

                                <label style="font-size: 0.85rem; font-weight: bold; color: #555;">
                                    📝 Mon petit mot sur lui...
                                </label>
                                <textarea name="mon_comm" 
                                          class="textarea-comm"
                                          placeholder="Écris quelque chose sur cet animal..."><?= htmlspecialchars($fav['commentaire_perso'] ?? '') ?></textarea>
                                <button type="submit" class="btn-save-comm">💾 Enregistrer mon avis</button>
                            </form>

                            <!-- FORMULAIRE DE SUPPRESSION DES FAVORIS -->
                            <form method="POST" action="favoris.php" 
                                  onsubmit="return confirm('Retirer cet animal de vos favoris ?')">
                                <input type="hidden" name="id_animal" value="<?= $fav['id_animal'] ?>">
                                <button type="submit" name="supprimer_favori" class="btn-remove-fav">
                                    ✕ Retirer des favoris
                                </button>
                            </form>
                        </div>

                    </div>

                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <!-- FOOTER -->
    <footer>
        <p><a href="#">Contact</a> | <a href="#">Mentions Légales</a> | <a href="#">Réseaux Sociaux</a></p>
        <p>© 2026 AdopteUnPote</p>
    </footer>

</body>
</html>
