<?php
session_start();
// Inclusion du fichier de configuration pour se connecter à la base de données
require_once 'config.php';

// SÉCURITÉ : Vérification des droits d'accès
// Si l'utilisateur n'est pas connecté ou s'il n'a pas le rôle 'admin',
// on le redirige vers la page d'accueil pour l'empêcher d'accéder à l'administration.
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php'); 
    exit(); // On arrête l'exécution du script
}

// Requête SQL pour récupérer TOUS les animaux et leurs catégories associées.
// On utilise une jointure (JOIN) entre la table 'animaux' et 'categories' 
// en faisant correspondre l'id de la catégorie (id_cat).
// On trie par ID décroissant (ORDER BY a.id_animal DESC) pour avoir les plus récents en premier.
$query = $pdo->query("SELECT a.*, c.nom_cat FROM animaux a JOIN categories c ON a.id_cat = c.id_cat ORDER BY a.id_animal DESC");

// fetchAll() récupère tous les résultats de la requête sous forme de tableau associatif.
$animaux = $query->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Console d'Administration - AdopteUnPote</title>
    <!-- Correction du lien vers le fichier CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🐾 Admin - AdopteUnPote</div>
        <nav>
            <a href="index.php">Retour au site</a>
            <a href="admin.php" class="nav-active">Animaux</a>
            <a href="admin_categories.php">Catégories</a>
            <a href="admin_users.php">Utilisateurs</a>
            <a href="demandes.php">Demandes</a>
        </nav>
    </header>

    <main class="container-admin">
        <h1>Gestion du Catalogue</h1>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>Photo</th>
                    <th>Nom</th>
                    <th>Catégorie</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Boucle foreach pour parcourir chaque animal récupéré dans la base de données -->
                <?php foreach($animaux as $a): ?>
                <tr>
                    <!-- Affichage de l'image de l'animal -->
                    <td><img src="img/<?= htmlspecialchars($a['image']) ?>" width="50" alt="<?= htmlspecialchars($a['nom_animal']) ?>"></td>
                    <!-- htmlspecialchars permet de sécuriser l'affichage contre les failles XSS -->
                    <td><?= htmlspecialchars($a['nom_animal']) ?></td>
                    <td><?= htmlspecialchars($a['nom_cat']) ?></td>
                    <td><span class="badge"><?= htmlspecialchars($a['statut']) ?></span></td>
                    <td>
                        <!-- Lien pour modifier un animal, on passe son ID dans l'URL (méthode GET) -->
                        <a href="edit.php?id=<?= $a['id_animal'] ?>" class="btn-edit">Modifier</a>
                        <!-- Lien pour supprimer un animal, on passe son ID dans l'URL. 
                             L'attribut onclick ajoute une boîte de dialogue de confirmation (JavaScript) avant d'exécuter le lien. -->
                        <a href="delete.php?id=<?= $a['id_animal'] ?>" class="btn-delete" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cet animal ? Cette action est irréversible.')">Supprimer</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>