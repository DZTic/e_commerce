<?php
// Démarrage de la session
session_start();

// Inclusion du fichier de configuration, pour la connexion PDO à la base de données
require 'config.php';

// Si l'utilisateur est déjà connecté, on le redirige vers l'accueil
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// Vérifie si le formulaire d'inscription a été soumis (méthode POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // 1. On vérifie d'abord si ce nom d'utilisateur (login) existe déjà dans la base
    $stmtCheck = $pdo->prepare("SELECT * FROM utilisateurs WHERE login = ?");
    $stmtCheck->execute([$username]);
    
    // Si fetch() retourne un résultat, c'est que l'utilisateur existe déjà
    if ($stmtCheck->fetch()) {
        $error = "Ce nom d'utilisateur est déjà pris. Veuillez en choisir un autre.";
    } else {
        // 2. Si le nom est disponible, on chiffre (hache) le mot de passe pour la sécurité
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // 3. Préparation de la requête pour insérer le nouvel utilisateur
        $stmtInsert = $pdo->prepare("INSERT INTO utilisateurs (login, password) VALUES (?, ?)");
        
        // Exécution de l'insertion
        if ($stmtInsert->execute([$username, $hashedPassword])) {
            // L'inscription a réussi. On connecte automatiquement l'utilisateur 
            // en récupérant l'ID de la ligne qui vient d'être insérée
            $_SESSION['user_id'] = $pdo->lastInsertId();
            $_SESSION['role'] = 'user'; // On attribue le rôle utilisateur par défaut
            
            // Redirection vers l'accueil
            header("Location: index.php");
            exit();
        } else {
            $error = "Une erreur s'est produite lors de l'inscription.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>AdopteUnPote - Inscription</title>
    <!-- Inclusion du fichier CSS principal du site -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- En-tête de la page (identique aux autres pages) -->
    <header>
        <div class="logo">🐾 AdopteUnPote</div>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="catalogue.php">Animaux</a>
            <a href="proposer.php">Proposer un animal</a>
            <!-- Le lien actif est mis en gras -->
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php" style="color: #d32f2f; font-weight: bold;">Se déconnecter</a>
            <?php else: ?>
                <a href="login.php" style="font-weight: bold; color: #000;">Connexion/Inscription</a>
            <?php endif; ?>
        </nav>
    </header>

    <!-- Contenu principal de la page -->
    <main class="login-main">
        <div class="auth-container">
            <h2>Inscription</h2>
            
            <!-- Si la variable $error existe, on l'affiche ici -->
            <?php if (isset($error)): ?>
                <div class="error-message">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <!-- Le formulaire envoie les données à la page elle-même en méthode POST -->
            <form method="post" class="auth-form">
                <!-- Groupe pour le nom d'utilisateur -->
                <div class="form-group">
                    <label for="username">Nom d'utilisateur</label>
                    <input type="text" id="username" name="username" placeholder="Choisissez un nom d'utilisateur" required>
                </div>

                <!-- Groupe pour le mot de passe -->
                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <input type="password" id="password" name="password" placeholder="Choisissez un mot de passe" required>
                </div>
                
                <!-- Bouton de soumission stylisé -->
                <button type="submit" class="btn-submit">S'inscrire</button>
            </form>
            
            <!-- Lien vers la page de connexion pour les utilisateurs existants -->
            <p class="auth-link">
                Déjà un compte ? <a href="login.php">Se connecter</a>
            </p>
        </div>
    </main>

    <!-- Pied de page (identique aux autres pages) -->
    <footer>
        <p><a href="#">Contact</a> | <a href="#">Mentions Légales</a> | <a href="#">Réseaux Sociaux</a></p>
        <p>© 2026 AdopteUnPote</p>
    </footer>
</body>
</html>
