<?php
session_start();
require 'config.php'; 

// On récupère les 4 derniers (l'image en montre 4, pas 3)
$query = $pdo->query("SELECT a.*, c.nom_cat 
                      FROM animaux a 
                      JOIN categories c ON a.id_cat = c.id_cat 
                      WHERE a.statut = 'disponible' 
                      ORDER BY a.date_ajout DESC LIMIT 4");
$derniers_animaux = $query->fetchAll();

// On récupère toutes les catégories depuis la base de données pour alimenter le sélecteur
$query_cat = $pdo->query("SELECT * FROM categories ORDER BY nom_cat ASC");
$categories = $query_cat->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>AdopteUnPote - Accueil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🐾 AdopteUnPote</div>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="catalogue.php">Animaux</a>
            <a href="proposer.php">Proposer un animal</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'gestionnaire'): ?>
                    <a href="<?= $_SESSION['role'] === 'admin' ? 'admin.php' : 'demandes.php' ?>">Administration</a>
                <?php endif; ?>
                <a href="mes_demandes.php">Mes Demandes</a>
                <a href="favoris.php">Mes Favoris ❤️</a>
                <a href="logout.php" style="color: #d32f2f; font-weight: bold;">Se déconnecter</a>
            <?php else: ?>
                <a href="login.php">Connexion/Inscription</a>
            <?php endif; ?>
        </nav>
    </header>

    <section class="hero">
        <div class="hero-content">
            <h1>Trouvez votre nouveau meilleur ami.</h1>
            <p>Des centaines d'animaux n'attendent que vous.</p>
            <a href="catalogue.php" class="btn-hero">Parcourir les animaux</a>
        </div>
    </section>

    <section class="search-bar">
        <h3>Moteur de Recherche Rapide</h3>
        <form action="catalogue.php" method="GET">
            <div class="search-group">
                <label>Sélecteur de catégorie</label>
                <select name="categorie">
                    <!-- Option par défaut (valeur vide = on ne filtre pas) -->
                    <option value="">Toutes les catégories</option>
                    
                    <?php 
                    /* On parcourt chaque catégorie trouvée dans la base de données.
                       Pour chaque catégorie, on crée une balise <option>.
                       - 'value' contiendra l'ID (id_cat) utile pour la recherche.
                       - Le texte affiché sera le nom de la catégorie (nom_cat). */
                    foreach ($categories as $cat): 
                    ?>
                        <option value="<?= $cat['id_cat'] ?>">
                            <?= htmlspecialchars($cat['nom_cat']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="search-group">
                <label>Code Postal</label>
                <input type="text" placeholder="Ex: 75000">
            </div>
            <button type="submit" class="btn-search">Chercher</button>
        </form>
    </section>

    <main>
        <h2>Les Dernières Pépites (Dernières annonces)</h2>
        <div class="grid-animaux">
            <?php foreach ($derniers_animaux as $animal): ?>
                <div class="card">
                    <div class="card-img-container">
                        <img src="img/<?= htmlspecialchars($animal['image']) ?>" alt="<?= htmlspecialchars($animal['nom_animal']) ?>" class="animal-photo">
                        <span class="heart-icon">♡</span>
                    </div>
                    <div class="card-body">
                        <h3><?= htmlspecialchars($animal['nom_animal']) ?></h3>
                        <p class="age"><?= htmlspecialchars($animal['age']) ?></p> <p class="category"><?= htmlspecialchars($animal['nom_cat']) ?></p>
                        <a href="fiche.php?id=<?= $animal['id_animal'] ?>" class="btn-card">Voir plus</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <footer>
        <p><a href="#">Contact</a> | <a href="#">Mentions Légales</a> | <a href="#">Réseaux Sociaux</a></p>
        <p>© 2026 AdopteUnPote</p>
    </footer>
</body>
</html>