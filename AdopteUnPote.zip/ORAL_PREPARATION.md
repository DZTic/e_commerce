# 📚 DOSSIER TECHNIQUE DE SOUTENANCE : Projet AdopteUnPote

Ce document constitue la base technique pour l'oral de présentation. Il détaille l'architecture, la sécurité et la logique algorithmique du système.

---

## 1. ARCHITECTURE GLOBALE & FLUX DE DONNÉES

### 🔄 Le Cycle de Vie d'une Page (Request-Response)
Le professeur peut vous demander : *"Que se passe-t-il techniquement quand je clique sur 'Voir plus' ?"*

**Le trajet est le suivant :**
1. **Navigateur (Client)** $\rightarrow$ Envoie une requête HTTP GET vers `fiche.php?id=X`.
2. **Serveur (PHP)** $\rightarrow$ 
    - Exécute `session_start()` pour identifier l'utilisateur.
    - Appelle `config.php` pour ouvrir la connexion **PDO** vers SQLite.
    - Récupère l'ID via `$_GET['id']` et le sécurise avec `intval()`.
    - Envoie une requête SQL préparée à la BDD.
3. **Base de Données (SQLite)** $\rightarrow$ Recherche l'animal et retourne la ligne correspondante.
4. **Serveur (PHP)** $\rightarrow$ 
    - Traite les données.
    - Génère le HTML en injectant les variables via `htmlspecialchars()`.
5. **Navigateur (Client)** $\rightarrow$ Reçoit le HTML final et l'affiche.

---

## 2. ANALYSE PROFONDE DU CODE (ZONES À RISQUE)

### 🔍 Le Système de Filtres (`catalogue.php`)
*C'est la partie la plus complexe du code. Le prof va sûrement vous demander d'expliquer la construction de la requête.*

**Logique algorithmique :**
1. **Collecte :** On récupère tous les critères (`$_GET['categorie']`, `$_GET['race']`, etc.).
2. **Construction Dynamique :** On crée un tableau `$conditions = []`. Si un filtre est rempli, on ajoute une chaîne SQL (ex: `"a.id_cat = :id_cat"`) et on stocke la valeur dans un tableau `$params`.
3. **Assemblage :** On joint toutes les conditions avec `implode(" AND ", $conditions)`.
4. **Exécution :** On utilise `prepare()` et `execute($params)` pour envoyer les données séparément de la commande.

**💡 Zoom sur un bout de code :**
`if ($filtre_categorie !== null) { $conditions[] = "a.id_cat = :id_cat"; $params[':id_cat'] = $filtre_categorie; }`

**Comment l'expliquer au prof :**
- **`if ($filtre_categorie !== null)`** $\rightarrow$ "Je vérifie d'abord si l'utilisateur a réellement choisi une catégorie. S'il n'a rien choisi, on ne doit pas filtrer, donc on ignore ce bloc."
- **`$conditions[] = "a.id_cat = :id_cat"`** $\rightarrow$ "J'ajoute un morceau de condition SQL dans mon tableau. Je n'écris pas la valeur directement, mais j'utilise un **marqueur** (`:id_cat`). C'est comme laisser un espace vide à remplir plus tard."
- **`$params[':id_cat'] = $filtre_categorie`** $\rightarrow$ "Je stocke la valeur réelle dans un tableau à part. En faisant cela, je sépare la **commande SQL** (la structure) des **données** (la valeur). C'est la méthode la plus efficace pour bloquer les **injections SQL**."

**Pourquoi c'est bien ?** Cela permet d'avoir des filtres optionnels : si l'utilisateur ne choisit rien, la requête reste simple (`SELECT *`). S'il choisit tout, la requête s'adapte.

### 🔐 Le Système d'Authentification (`login.php` / `register.php`)
**Le flux de sécurité :**
- **Inscription :** `Mot de passe` $\rightarrow$ `password_hash()` $\rightarrow$ `Stockage BDD`.
- **Connexion :** `Saisie utilisateur` $\rightarrow$ `password_verify(Saisie, Hash_BDD)` $\rightarrow$ `Vrai/Faux`.

**Concept clé :** Le **Hachage**. Expliquez que même si la base de données est volée, les mots de passe sont illisibles et impossibles à retrouver (contrairement au chiffrement, le hachage est à sens unique).

---

## 3. 📖 DICTIONNAIRE DES VARIABLES (Vocabulaire technique)

Si le professeur vous demande : *"À quoi sert cette variable à la ligne X ?"*, utilisez ce guide.

### 🌍 Variables Globales (Superglobales PHP)
| Variable | Rôle | Exemple d'utilisation |
| :--- | :--- | :--- |
| `$_SESSION` | Stocke les infos de l'utilisateur connecté sur le serveur. | `$_SESSION['user_id']` pour savoir qui est connecté. |
| `$_GET` | Récupère les données passées dans l'URL (après le `?`). | `$_GET['id']` pour savoir quel animal afficher. |
| `$_POST` | Récupère les données envoyées via un formulaire (cachées). | `$_POST['password']` lors de la connexion. |
| `$_FILES` | Contient les informations sur les fichiers uploadés. | `$_FILES['image']` pour récupérer la photo d'un animal. |
| `$_SERVER` | Infos sur le serveur et la requête. | `$_SERVER['REQUEST_METHOD']` pour savoir si c'est un POST ou GET. |

### 🗄️ Variables liées à la Base de Données (PDO)
| Variable | Rôle | Explication |
| :--- | :--- | :--- |
| `$pdo` | L'objet de connexion. | C'est le "pont" entre PHP et SQLite. Sans lui, pas de BDD. |
| `$query` | Le résultat d'une requête simple. | Utilisé pour les `SELECT` basiques (ex: charger les catégories). |
| `$stmt` | Un "Statement" (Requête préparée). | Utilisé pour les requêtes sécurisées avec des paramètres (`?` ou `:nom`). |
| `$stmt_get_anima` | Requête préparée ( lecture ). | Utilisé spécifiquement pour récupérer les infos d'un animal précis. |
| `$stmt_update_animal` | Requête préparée ( modification ). | Utilisé pour mettre à jour le statut ou les infos d'un animal. |
| `$stmt_count` | Statement de comptage. | L'objet PDO utilisé pour exécuter la requête qui compte le nombre total d'éléments (utilisé pour la pagination). |
| `$sql_count` | Requête de comptage. | La commande SQL `SELECT COUNT(*)...` permettant de savoir combien d'animaux correspondent aux filtres. |
| `?` | Placeholder (marqueur). | Indique l'emplacement d'une valeur qui sera injectée plus tard via `execute()`. Empêche les injections SQL. |
| `$params` | Tableau de valeurs. | Contient les données à injecter dans une requête préparée pour éviter les injections SQL. |
| `$animaux` | Tableau de données. | Contient tous les animaux récupérés via `$query->fetchAll()`. |
| `fetch()` | Méthode PDO. | Récupère la ligne suivante du résultat d'une requête (utile pour un seul animal). |
| `fetchAll()` | Méthode PDO. | Récupère toutes les lignes du résultat d'une requête d'un coup (utile pour le catalogue). |
| `beginTransaction` | Méthode PDO | Démarre une transaction : groupe plusieurs requêtes pour qu'elles réussissent toutes ou aucune. |
| `commit` | Méthode PDO | Valide et enregistre définitivement les changements de la transaction. |
| `rollBack` | Méthode PDO | Annule toutes les modifications de la transaction en cas d'erreur (sécurité). |

### ⚙️ Variables de Logique et d'Affichage
| Variable | Rôle | Explication |
| :--- | :--- | :--- |
| `!isset()` | Opérateur de vérification | Vérifie si une variable n'est PAS définie. Utile pour gérer les erreurs de données manquantes. |
| `intval()` | Fonction de conversion | Transforme une valeur en entier. Crucial pour sécuriser les IDs dans l'URL contre les injections. |
| `strtolower()` | Fonction de chaîne | Transforme tout le texte en minuscules. Utile pour comparer des statuts sans se soucier des majuscules. |
| `implode()` | Fonction de chaîne | Permet de joindre les éléments d'un tableau en une seule chaîne de caractères (utilisé pour assembler les conditions SQL). |
| `getMessage()` | Méthode d'Exception | Récupère le message d'erreur technique lorsqu'un bloc `try...catch` capture une erreur. |
| `$e` | Objet Exception | Représente l'erreur qui vient de se produire. On l'utilise pour afficher le message via `$e->getMessage()`. |
| `$users` | Tableau d'utilisateurs | Stocke la liste complète des utilisateurs récupérés depuis la base de données. |
| `$u` | Variable de boucle | Représente l'utilisateur actuel lors d'un parcours de la liste `$users` (dans un `foreach`). |
| `$conditions` | Liste de filtres SQL. | Dans `catalogue.php`, stocke les morceaux de `WHERE` (ex: `a.genre = 'male'`). |
| `$error` | Message d'erreur. | Stocke le texte à afficher en rouge si un formulaire est mal rempli. |
| `$success` | Message de succès. | Stocke le texte à afficher en vert après une action réussie. |
| `$success_msg` | Message de succès (Local) | Variable utilisée pour confirmer la réussite d'une mise à jour de statut. |
| `$error_msg` | Message d'erreur (Local) | Variable utilisée pour signaler l'échec d'une modification en base de données. |
| `$id_animal` | Identifiant unique. | Variable locale utilisée pour cibler un animal précis (souvent convertie avec `intval()`). |
| `$nouveau_statut` | Valeur de mise à jour | Stocke le nouveau statut d'un animal (ex: 'Adopté') avant de l'envoyer à la BDD. |

### 🌐 Syntaxe HTML & Structures PHP
| Terme | Type | Rôle |
| :--- | :--- | :--- |
| `href` | Attribut HTML | Définit l'adresse de destination d'un lien hypertexte. |
| `<thead>` | Balise HTML | Regroupe le contenu d'en-tête d'un tableau (titres des colonnes). |
| `endforeach;` | Structure PHP | Ferme une boucle `foreach` (syntaxe alternative pour le HTML). |
| `endif;` | Structure PHP | Ferme un bloc conditionnel `if` (syntaxe alternative pour le HTML). |

---

## 4. MATRICE DE SÉCURITÉ (L'argumentaire)

Si le prof vous demande : *"Comment avez-vous sécurisé votre application ?"*, répondez avec ce tableau :

| Menace | Solution implémentée | Fonction/Méthode utilisée |
| :--- | :--- | :--- |
| **Injection SQL** | Requêtes Préparées | `PDO::prepare()` $\rightarrow$ `execute()` |
| **Faille XSS** | Échappement des caractères | `htmlspecialchars()` |
| **Vol de Mots de Passe** | Hachage cryptographique | `password_hash()` / `password_verify()` |
| **Accès Non Autorisé** | Contrôle de Session | `$_SESSION['role']` + `header('Location: ...')` |
| **Données Corrompues** | Typage forcé | `intval()` pour les IDs dans l'URL |

---

## 5. SCHÉMA RELATIONNEL (BDD)

**Relations clés à expliquer :**
- **`categories` $\rightarrow$ `animaux`** : Relation **1:N**. (Une catégorie contient plusieurs animaux. Si on supprime une catégorie, on peut décider de mettre `id_cat` à NULL via `ON DELETE SET NULL`).
- **`utilisateurs` $\rightarrow$ `favoris` $\leftarrow$ `animaux`** : Table de jointure pour une relation **N:N**. C'est ce qui permet à plusieurs utilisateurs d'aimer le même animal.

---

## 6. AUTO-CRITIQUE & PERSPECTIVES (Le bonus "Mention Très Bien")

Le prof adore quand un étudiant sait ce qui manque à son projet. S'il vous demande *"Qu'est-ce que vous pourriez améliorer ?"*, donnez ces 3 points :

1. **Pagination Avancée :** "Actuellement, la pagination est simple. Je pourrais ajouter un système de 'chargement infini' (Infinite Scroll) en JavaScript/AJAX pour une meilleure expérience utilisateur."
2. **Validation Côté Client :** "J'ai sécurisé le serveur, mais je pourrais ajouter des validations en JavaScript (Regex) dans les formulaires pour alerter l'utilisateur instantanément avant l'envoi."
3. **Gestion des Images :** "L'upload actuel est basique. Je pourrais implémenter un redimensionnement automatique des images (avec la bibliothèque GD ou Imagick) pour optimiser le temps de chargement des pages."

---

## 7. RÉSUMÉ DES RÉPONSES RAPIDES (Flashcards)

- **"C'est quoi PDO ?"** $\rightarrow$ Une interface PHP pour communiquer avec n'importe quelle BDD de façon sécurisée.
- **"Pourquoi `session_start()` ?"** $\rightarrow$ Pour créer un lien persistant entre le serveur et le client via un cookie de session.
- **"À quoi sert `$_POST` vs `$_GET` ?"** $\rightarrow$ `GET` passe les données dans l'URL (idéal pour la recherche/filtres). `POST` cache les données dans le corps de la requête (indispensable pour les mots de passe et l'upload de fichiers).
- **"Pourquoi `require_once` plutôt que `include` ?"** $\rightarrow$ `require_once` arrête le script s'il y a une erreur et empêche de charger le fichier plusieurs fois, ce qui éviterait des erreurs de redéclaration de variables.
