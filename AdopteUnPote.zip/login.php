<?php
// Démarrage de la session pour pouvoir stocker et utiliser des variables de session (comme l'état de connexion de l'utilisateur)
session_start();

// Inclusion du fichier de configuration, généralement utilisé pour établir la connexion à la base de données (initialise la variable $pdo)
require 'config.php';

// Si l'utilisateur est déjà connecté (la variable 'user_id' existe dans la session),
// on le redirige directement vers la page d'accueil car il n'a pas besoin de se reconnecter.
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit(); // On arrête toujours l'exécution du script après une redirection header()
}

// Vérifie si le formulaire de connexion a été soumis (si la méthode HTTP utilisée est POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Préparation d'une requête SQL sécurisée pour chercher l'utilisateur via son nom d'utilisateur
    // Dans la base de données, la table s'appelle "utilisateurs" et la colonne du nom d'utilisateur est "login"
    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE login = ?");
    
    // 2. Exécution de la requête en passant de manière sécurisée la valeur du champ 'username' envoyée par le formulaire
    $stmt->execute([$_POST['username']]);
    
    // 3. Récupération des données de l'utilisateur correspondant (s'il existe en base de données)
    $user = $stmt->fetch();

    // 4. Vérification des identifiants :
    // On s'assure d'abord que l'utilisateur a été trouvé ($user n'est pas vide)
    // Ensuite, on vérifie que le mot de passe tapé correspond au mot de passe chiffré (haché) stocké dans la base
    if ($user && password_verify($_POST['password'], $user['password'])) {
        // Connexion réussie : on enregistre l'ID et le rôle de l'utilisateur dans la session
        $_SESSION['user_id'] = $user['id_user'];
        $_SESSION['role'] = $user['role'];
        
        // On redirige l'utilisateur vers la page d'accueil une fois connecté
        header("Location: index.php");
        exit();
    } else {
        // Si le nom d'utilisateur n'existe pas ou si le mot de passe est faux, on définit un message d'erreur
        $error = "Identifiants incorrects";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>AdopteUnPote - Connexion</title>
    <!-- Inclusion du fichier CSS principal du site -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- En-tête de la page (identique aux autres pages) -->
    <header>
        <div class="logo">🐾 AdopteUnPote</div>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="catalogue.php">Animaux</a>
            <a href="proposer.php">Proposer un animal</a>
            <!-- Le lien actif est mis en gras -->
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php" style="color: #d32f2f; font-weight: bold;">Se déconnecter</a>
            <?php else: ?>
                <a href="login.php" style="font-weight: bold; color: #000;">Connexion/Inscription</a>
            <?php endif; ?>
        </nav>
    </header>

    <!-- Contenu principal de la page -->
    <main class="login-main">
        <div class="auth-container">
            <h2>Connexion</h2>
            
            <!-- Si la variable $error existe (définie plus haut suite à une tentative échouée), on l'affiche ici -->
            <?php if (isset($error)): ?>
                <div class="error-message">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <!-- Le formulaire envoie les données à la page elle-même en méthode POST -->
            <form method="post" class="auth-form">
                <!-- Groupe pour le nom d'utilisateur -->
                <div class="form-group">
                    <label for="username">Nom d'utilisateur</label>
                    <!-- Champ obligatoire pour le nom d'utilisateur -->
                    <input type="text" id="username" name="username" placeholder="Entrez votre nom d'utilisateur" required>
                </div>

                <!-- Groupe pour le mot de passe -->
                <div class="form-group">
                    <label for="password">Mot de passe</label>
                    <!-- Champ obligatoire pour le mot de passe (les caractères sont masqués) -->
                    <input type="password" id="password" name="password" placeholder="Entrez votre mot de passe" required>
                </div>
                
                <!-- Bouton de soumission stylisé -->
                <button type="submit" class="btn-submit">Se connecter</button>
            </form>
            
            <!-- Lien vers la page d'inscription pour les nouveaux utilisateurs -->
            <p class="auth-link">
                Pas encore de compte ? <a href="register.php">S'inscrire</a>
            </p>
        </div>
    </main>

    <!-- Pied de page (identique aux autres pages) -->
    <footer>
        <p><a href="#">Contact</a> | <a href="#">Mentions Légales</a> | <a href="#">Réseaux Sociaux</a></p>
        <p>© 2026 AdopteUnPote</p>
    </footer>
</body>
</html>
