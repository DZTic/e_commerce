<?php
session_start();
require_once 'config.php';

// PROTECTION : page réservée aux utilisateurs connectés
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$id_user = $_SESSION['user_id'];

// RÉCUPÉRER LES DEMANDES DE L'UTILISATEUR
$query = $pdo->prepare("
    SELECT d.*, a.nom_animal, a.image 
    FROM demandes_adoption d
    JOIN animaux a ON d.id_animal = a.id_animal
    WHERE d.id_user = ?
    ORDER BY d.date_demande DESC
");
$query->execute([$id_user]);
$mes_demandes = $query->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mes Demandes d'Adoption - AdopteUnPote</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .demandes-container { padding: 40px 50px; background: #f4f7f9; min-height: 80vh; }
        .demandes-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; margin-top: 20px; }
        .demande-card { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05); display: flex; flex-direction: column; }
        .demande-img { width: 100%; height: 180px; object-fit: cover; }
        .demande-info { padding: 20px; flex-grow: 1; }
        .demande-info h3 { margin: 0 0 10px 0; color: #333; }
        .demande-date { font-size: 0.85rem; color: #777; margin-bottom: 10px; }
        .demande-msg { font-size: 0.9rem; color: #555; background: #f9f9f9; padding: 10px; border-radius: 5px; margin-bottom: 15px; border-left: 3px solid #ddd; }
        .status-badge { display: inline-block; padding: 6px 12px; border-radius: 20px; font-size: 0.85rem; font-weight: bold; text-transform: capitalize; }
        .status-en_attente { background: #fff3cd; color: #856404; }
        .status-validee { background: #d4edda; color: #155724; }
        .status-refusee { background: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <header>
        <div class="logo">🐾 AdopteUnPote</div>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="catalogue.php">Animaux</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'gestionnaire'): ?>
                    <a href="<?= $_SESSION['role'] === 'admin' ? 'admin.php' : 'demandes.php' ?>">Administration</a>
                <?php endif; ?>
                <a href="mes_demandes.php" style="font-weight: bold; color: #479354;">Mes Demandes</a>
                <a href="favoris.php">Mes Favoris ❤️</a>
                <a href="logout.php" style="color: #d32f2f; font-weight: bold;">Se déconnecter</a>
            <?php else: ?>
                <a href="login.php">Connexion/Inscription</a>
            <?php endif; ?>
        </nav>
    </header>

    <main class="demandes-container">
        <h1>🐾 Mes Demandes d'Adoption</h1>
        <p>Retrouvez ici le suivi de vos demandes pour nos petits protégés.</p>

        <?php if (empty($mes_demandes)): ?>
            <div style="text-align: center; margin-top: 50px;">
                <p>Vous n'avez pas encore envoyé de demande d'adoption.</p>
                <a href="catalogue.php" class="btn-hero" style="display: inline-block; margin-top: 20px; text-decoration: none; background: #479354; color: white; padding: 10px 25px; border-radius: 30px;">Parcourir les animaux</a>
            </div>
        <?php else: ?>
            <div class="demandes-grid">
                <?php foreach ($mes_demandes as $d): ?>
                    <div class="demande-card">
                        <img src="img/<?= htmlspecialchars($d['image']) ?>" class="demande-img" alt="<?= htmlspecialchars($d['nom_animal']) ?>">
                        <div class="demande-info">
                            <h3><?= htmlspecialchars($d['nom_animal']) ?></h3>
                            <div class="demande-date">Envoyée le <?= date('d/m/Y', strtotime($d['date_demande'])) ?></div>
                            
                            <?php if (!empty($d['message'])): ?>
                                <div class="demande-msg">
                                    "<?= nl2br(htmlspecialchars($d['message'])) ?>"
                                </div>
                            <?php endif; ?>

                            <div style="margin-top: 15px;">
                                <?php 
                                $badge_class = 'status-' . strtolower($d['statut']);
                                $display_statut = ($d['statut'] === 'en_attente') ? 'En attente' : $d['statut'];
                                ?>
                                <span class="status-badge <?= $badge_class ?>">
                                    <?= htmlspecialchars($display_statut) ?>
                                </span>
                            </div>
                        </div>
                        <div style="padding: 15px; border-top: 1px solid #eee; text-align: center;">
                            <a href="fiche.php?id=<?= $d['id_animal'] ?>" style="color: #479354; text-decoration: none; font-size: 0.9rem; font-weight: bold;">Voir la fiche →</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <footer>
        <p><a href="#">Contact</a> | <a href="#">Mentions Légales</a> | <a href="#">Réseaux Sociaux</a></p>
        <p>© 2026 AdopteUnPote</p>
    </footer>
</body>
</html>
