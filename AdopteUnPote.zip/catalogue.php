<?php
session_start();
// ============================================================
// CATALOGUE.PHP — Page catalogue complète avec sidebar de filtres
// ============================================================
//
// RÔLE DE CE FICHIER :
//   C'est la page principale de navigation des animaux.
//   Elle affiche TOUS les animaux (ou filtrés) en grille 5 colonnes.
//
// COMMENT IL SE CONNECTE AUX AUTRES FICHIERS :
//
//   → config.php   : Inclus via require_once pour obtenir la variable
//                    $pdo (connexion SQLite). Sans lui, aucune donnée.
//
//   → fiche.php    : Chaque carte animal contient un lien
//                    "Voir plus" qui pointe vers fiche.php?id=X.
//                    L'ID est l'identifiant unique de l'animal en BDD.
//
//   → favoris.php  : Le bouton cœur (♡) dans chaque carte soumet
//                    un formulaire POST vers fiche.php pour ajouter
//                    l'animal aux favoris. La sidebar contient aussi
//                    un lien direct vers favoris.php.
//
//   → login.php    : Si l'utilisateur n'est pas connecté
//                    (pas de $_SESSION['user_id']), le cœur renvoie
//                    vers fiche.php qui redirigera vers login.php.
//
//   → style.css    : La classe body.page-catalogue applique le fond
//                    bleu. Les classes .sidebar, .grid-catalogue,
//                    .card-cat, .pagination stylisent toute la page.
//
// FLUX DES DONNÉES :
//   1. Le navigateur charge catalogue.php (avec éventuellement
//      des paramètres GET : ?categorie=2&tri=age_asc&page=2)
//   2. PHP lit ces paramètres et construit la requête SQL
//   3. La BDD retourne les animaux filtrés + paginés
//   4. PHP génère le HTML avec les données
//   5. Le navigateur affiche la page
// ============================================================

require_once 'config.php';

// -------------------------------------------------------
// RÉCUPÉRATION DES FILTRES DEPUIS L'URL (méthode GET)
// -------------------------------------------------------
$filtre_categorie = isset($_GET['categorie']) && $_GET['categorie'] !== '' ? (int)$_GET['categorie'] : null;
$filtre_genre     = isset($_GET['genre'])     && $_GET['genre']     !== '' ? $_GET['genre']           : null;
$filtre_taille    = isset($_GET['taille'])    && is_array($_GET['taille'])  ? $_GET['taille']         : [];
$age_min          = isset($_GET['age_min'])   && $_GET['age_min']   !== '' ? (int)$_GET['age_min']    : null;
$age_max          = isset($_GET['age_max'])   && $_GET['age_max']   !== '' ? (int)$_GET['age_max']    : null;
$tri              = isset($_GET['tri'])        && $_GET['tri']       !== '' ? $_GET['tri']             : 'recent';

// -------------------------------------------------------
// PAGINATION : 10 animaux par page
// -------------------------------------------------------
$par_page = 10;
$page_actuelle = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page_actuelle - 1) * $par_page;

// -------------------------------------------------------
// CONSTRUCTION DE LA REQUÊTE SQL avec filtres dynamiques
// -------------------------------------------------------
$conditions = ["a.statut = 'disponible'"];
$params = [];

// Filtre catégorie
if ($filtre_categorie !== null) {
    $conditions[] = "a.id_cat = :id_cat";
    $params[':id_cat'] = $filtre_categorie;
}

// Filtre genre (male / femelle) — correspond à la colonne 'genre' en BDD
if ($filtre_genre !== null) {
    $conditions[] = "a.genre = :genre";
    $params[':genre'] = $filtre_genre;
}

// Filtre taille (petit / moyen / grand) — plusieurs valeurs possibles (checkboxes)
if (!empty($filtre_taille)) {
    // On génère des placeholders : (:t0, :t1, :t2...)
    $placeholders = [];
    foreach ($filtre_taille as $i => $val) {
        $key = ':taille' . $i;
        $placeholders[]   = $key;
        $params[$key]     = $val;
    }
    $conditions[] = "a.taille IN (" . implode(',', $placeholders) . ")";
}

// Filtre âge (min / max)
$age_expr = "CASE WHEN a.age LIKE '%an%' THEN CAST(a.age AS REAL) WHEN a.age LIKE '%mois%' THEN CAST(a.age AS REAL) / 12.0 ELSE CAST(a.age AS REAL) END"; // convertie l'âge en mois pour que le filtre fonctionne
if ($age_min !== null) {
    $conditions[] = "($age_expr) >= CAST(:age_min AS REAL)";
    $params[':age_min'] = $age_min;
}
if ($age_max !== null) {
    $conditions[] = "($age_expr) <= CAST(:age_max AS REAL)";
    $params[':age_max'] = $age_max;
}

// Tri
$order_sql = "a.date_ajout DESC"; // Par défaut : plus récent
if ($tri === 'age_asc')  $order_sql = "a.age ASC";
if ($tri === 'age_desc') $order_sql = "a.age DESC";
if ($tri === 'nom_asc')  $order_sql = "a.nom_animal ASC";

// Clause WHERE finale
$where = count($conditions) > 0 ? "WHERE " . implode(" AND ", $conditions) : "";

// Requête pour compter le total (pour la pagination)
$sql_count = "SELECT COUNT(*) FROM animaux a JOIN categories c ON a.id_cat = c.id_cat $where"; // Compte le nombre total d'animaux avec les filtres
$stmt_count = $pdo->prepare($sql_count); // prépare la requete pour compter le nombre total d'animaux avec les filtres
$stmt_count->execute($params); // execute la requete pour compter le nombre total d'animaux avec les filtres
$total_animaux = $stmt_count->fetchColumn(); // compte le nombre total d'animaux qui correspondent aux filtres
$total_pages = max(1, ceil($total_animaux / $par_page)); // calcule le nombre de pages en divisant le nombre total d'animaux par le nombre d'animaux par page

// Requête principale avec LIMIT/OFFSET pour la pagination
$sql = "SELECT a.*, c.nom_cat 
        FROM animaux a 
        JOIN categories c ON a.id_cat = c.id_cat 
        $where 
        ORDER BY $order_sql
        LIMIT :limit OFFSET :offset"; // limite le nombre d'animaux par page et offset pour la pagination
$stmt = $pdo->prepare($sql);
foreach ($params as $key => $val) {
    $stmt->bindValue($key, $val);
}
$stmt->bindValue(':limit',  $par_page, PDO::PARAM_INT); // limite le nombre d'animaux par page
$stmt->bindValue(':offset', $offset,   PDO::PARAM_INT); // offset pour la pagination
$stmt->execute();
$tous_les_animaux = $stmt->fetchAll(); // récupère tous les animaux avec les filtres

// Catégories pour la sidebar
$query_cat = $pdo->query("SELECT * FROM categories ORDER BY nom_cat ASC");
$categories = $query_cat->fetchAll();

// Favoris de l'utilisateur courant (pour afficher les cœurs pleins)
$ids_favoris = [];
if (isset($_SESSION['user_id'])) {
    $id_user_fav = $_SESSION['user_id'];
    $stmt_fav = $pdo->prepare("SELECT id_animal FROM favoris WHERE id_user = ?");
    $stmt_fav->execute([$id_user_fav]);
    $ids_favoris = $stmt_fav->fetchAll(PDO::FETCH_COLUMN);
}

// Construire la query string actuelle sans 'page' pour les liens de pagination (toujours dans les favoris)
$params_url = $_GET; // récupère tous les paramètres GET
unset($params_url['page']); // supprime la clé 'page' du tableau des paramètres
$base_url = '?' . http_build_query($params_url); // construit la query string
if ($base_url === '?') $base_url = '?'; // si la query string est vide, la laisse vide
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Catalogue - AdopteUnPote</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="page-catalogue">

    <!-- ===== HEADER ===== -->
    <header>
        <div class="logo">🐾 AdopteUnPote</div>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="catalogue.php" class="nav-active">Animaux</a>
            <a href="proposer.php">Proposer un animal</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'gestionnaire'): ?>
                    <a href="<?= $_SESSION['role'] === 'admin' ? 'admin.php' : 'demandes.php' ?>">Administration</a>
                <?php endif; ?>
                <a href="mes_demandes.php">Mes Demandes</a>
                <a href="favoris.php">Mes Favoris ❤️</a>
                <a href="logout.php" style="color: #d32f2f; font-weight: bold;">Se déconnecter</a>
            <?php else: ?>
                <a href="login.php">Connexion/Inscription</a>
            <?php endif; ?>
        </nav>
    </header>

    <!-- ===== ZONE PRINCIPALE ===== -->
    <div class="catalogue-wrapper">

        <!-- Titre principal EN DEHORS du layout deux colonnes -->
        <h1 class="catalogue-title">Catalogue Complet des Animaux</h1>

        <!-- Layout deux colonnes -->
        <div class="container-catalogue">

            <!-- ===== SIDEBAR GAUCHE ===== -->
            <aside class="sidebar">

                <!-- Titre des filtres -->
                <h3 class="sidebar-title">Filtres de Recherche</h3>

                <form action="catalogue.php" method="GET" id="form-filtres">

                    <!-- Filtre 1 : Catégorie -->
                    <div class="filter-group">
                        <label class="filter-label">Sélecteur de catégorie</label>
                        <select name="categorie" class="filter-select">
                            <option value="">Toutes les catégories</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= $c['id_cat'] ?>"
                                    <?= ($filtre_categorie === (int)$c['id_cat']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['nom_cat']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>



                    <!-- Filtre 3 : Âge (min/max + slider) -->
                    <div class="filter-group">
                        <label class="filter-label">Âge</label>
                        <div class="age-inputs">
                            <input type="number" name="age_min" class="filter-input age-input"
                                   placeholder="Min" min="0" max="20"
                                   value="<?= $age_min ?? '' ?>">
                            <input type="number" name="age_max" class="filter-input age-input"
                                   placeholder="Max" min="0" max="20"
                                   value="<?= $age_max ?? '' ?>">
                        </div>
                        <!-- Slider visuel (décoratif pour correspondre à la maquette) -->
                        <div class="age-slider-track">
                            <div class="age-slider-fill"></div>
                        </div>
                    </div>

                    <!-- Filtre 4 : Genre (boutons radio) -->
                    <div class="filter-group">
                        <label class="filter-label">Genre</label>
                        <div class="radio-group">
                            <label class="radio-label">
                                <input type="radio" name="genre" value="male"
                                    <?= ($filtre_genre === 'male') ? 'checked' : '' ?>>
                                Mâle
                            </label>
                            <label class="radio-label">
                                <input type="radio" name="genre" value="femelle"
                                    <?= ($filtre_genre === 'femelle') ? 'checked' : '' ?>>
                                Femelle
                            </label>
                            <label class="radio-label">
                                <input type="radio" name="genre" value=""
                                    <?= (!$filtre_genre) ? 'checked' : '' ?>>
                                Indifférent
                            </label>
                        </div>
                    </div>

                    <!-- Filtre 5 : Taille (cases à cocher) -->
                    <div class="filter-group">
                        <label class="filter-label">Taille</label>
                        <div class="checkbox-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="taille[]" value="petit"
                                    <?= in_array('petit', $filtre_taille) ? 'checked' : '' ?>>
                                Petit
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="taille[]" value="moyen"
                                    <?= in_array('moyen', $filtre_taille) ? 'checked' : '' ?>>
                                Moyen
                            </label>
                            <label class="checkbox-label">
                                <input type="checkbox" name="taille[]" value="grand"
                                    <?= in_array('grand', $filtre_taille) ? 'checked' : '' ?>>
                                Grand
                            </label>
                        </div>
                    </div>

                    <!-- Bouton appliquer -->
                    <button type="submit" class="btn-filter">Appliquer les filtres</button>

                    <?php if ($filtre_categorie || $filtre_genre || !empty($filtre_taille) || $age_min !== null || $age_max !== null): ?>
                        <a href="catalogue.php" class="btn-reset">✕ Réinitialiser</a>
                    <?php endif; ?>

                </form>

                <!-- Section Mes Favoris dans la sidebar -->
                <div class="sidebar-favoris">
                    <a href="favoris.php" class="sidebar-favoris-link">
                        <span class="heart-fill">♥</span> Mes Favoris
                    </a>
                </div>

            </aside>

            <!-- ===== CONTENU PRINCIPAL ===== -->
            <main class="content">

                <!-- Barre de tri -->
                <div class="sort-bar">
                    <span class="sort-label">Trier par :</span>
                    <form action="catalogue.php" method="GET" id="form-tri" style="display:inline;">
                        <!-- Conserver les filtres actifs dans la form de tri -->
                        <?php if ($filtre_categorie): ?>
                            <input type="hidden" name="categorie" value="<?= $filtre_categorie ?>">
                        <?php endif; ?>
                        <?php if ($age_min !== null): ?>
                            <input type="hidden" name="age_min" value="<?= $age_min ?>">
                        <?php endif; ?>
                        <?php if ($age_max !== null): ?>
                            <input type="hidden" name="age_max" value="<?= $age_max ?>">
                        <?php endif; ?>
                        <?php if ($filtre_genre): ?>
                            <input type="hidden" name="genre" value="<?= htmlspecialchars($filtre_genre) ?>">
                        <?php endif; ?>
                        <?php foreach ($filtre_taille as $t): ?>
                            <input type="hidden" name="taille[]" value="<?= htmlspecialchars($t) ?>">
                        <?php endforeach; ?>


                        <select name="tri" class="sort-select" onchange="this.form.submit()">
                            <option value="recent"   <?= $tri === 'recent'   ? 'selected' : '' ?>>Plus récent</option>
                            <option value="age_asc"  <?= $tri === 'age_asc'  ? 'selected' : '' ?>>Âge croissant</option>
                            <option value="age_desc" <?= $tri === 'age_desc' ? 'selected' : '' ?>>Âge décroissant</option>
                            <option value="nom_asc"  <?= $tri === 'nom_asc'  ? 'selected' : '' ?>>Nom A→Z</option>
                        </select>
                    </form>
                </div>

                <?php if (count($tous_les_animaux) === 0): ?>
                    <div class="empty-results">
                        <p>😔 Aucun animal ne correspond à votre recherche.</p>
                        <a href="catalogue.php" class="btn-filter">Voir tous les animaux</a>
                    </div>
                <?php else: ?>

                    <!-- GRILLE 5 COLONNES -->
                    <div class="grid-catalogue">
                        <?php foreach ($tous_les_animaux as $animal): ?>
                            <?php $est_fav = in_array($animal['id_animal'], $ids_favoris); ?>
                            <div class="card-cat">
                                <!-- Image de l'animal -->
                                <div class="card-cat-img">
                                    <img src="img/<?= htmlspecialchars($animal['image']) ?>"
                                         alt="<?= htmlspecialchars($animal['nom_animal']) ?>">
                                </div>
                                <!-- Infos : nom + cœur sur même ligne, âge, catégorie -->
                                <div class="card-cat-body">
                                    <div class="card-cat-header">
                                        <span class="card-cat-name"><?= htmlspecialchars($animal['nom_animal']) ?></span>
                                        <!-- Cœur favori : pointe vers toggle_favori.php -->
                                        <!-- Après l'action, on est redirigé VERS CATALOGUE (pas vers fiche) -->
                                        <form method="POST" action="toggle_favori.php" class="heart-form">
                                            <!-- ID de l'animal à mettre en favori -->
                                            <input type="hidden" name="id_animal" value="<?= $animal['id_animal'] ?>">
                                            <!-- Page de retour après l'action -->
                                            <input type="hidden" name="redirect_to" value="catalogue.php">
                                            <button type="submit"
                                                    class="heart-btn <?= $est_fav ? 'heart-active' : '' ?>"
                                                    title="<?= $est_fav ? 'Retirer des favoris' : 'Ajouter aux favoris' ?>">
                                                <?= $est_fav ? '♥' : '♡' ?>
                                            </button>
                                        </form>
                                    </div>
                                    <p class="card-cat-age"><?= htmlspecialchars($animal['age']) ?></p>
                                    <p class="card-cat-cat"><?= htmlspecialchars($animal['nom_cat']) ?></p>
                                    <a href="fiche.php?id=<?= $animal['id_animal'] ?>" class="btn-voir-plus">Voir plus</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- ===== PAGINATION ===== -->
                    <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <!-- Bouton précédent -->
                        <?php if ($page_actuelle > 1): ?>
                            <a href="<?= $base_url ?>&page=<?= $page_actuelle - 1 ?>" class="page-btn page-nav">‹</a>
                        <?php else: ?>
                            <span class="page-btn page-nav page-disabled">‹</span>
                        <?php endif; ?>

                        <?php
                        // Afficher les numéros de pages (avec "..." si trop de pages)
                        for ($p = 1; $p <= $total_pages; $p++):
                            if ($p === 1 || $p === $total_pages || ($p >= $page_actuelle - 1 && $p <= $page_actuelle + 1)):
                        ?>
                            <a href="<?= $base_url ?>&page=<?= $p ?>"
                               class="page-btn <?= $p === $page_actuelle ? 'page-active' : '' ?>">
                                <?= $p ?>
                            </a>
                        <?php
                            elseif ($p === $page_actuelle - 2 || $p === $page_actuelle + 2):
                                echo '<span class="page-btn page-dots">...</span>';
                            endif;
                        endfor;
                        ?>

                        <!-- Bouton suivant -->
                        <?php if ($page_actuelle < $total_pages): ?>
                            <a href="<?= $base_url ?>&page=<?= $page_actuelle + 1 ?>" class="page-btn page-nav">›</a>
                        <?php else: ?>
                            <span class="page-btn page-nav page-disabled">›</span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                <?php endif; ?>

            </main>
        </div>
    </div>

    <!-- ===== FOOTER ===== -->
    <footer>
        <p><a href="#">Contact</a> | <a href="#">Mentions Légales</a> | <a href="#">Réseaux Sociaux</a></p>
        <p>© 2026 AdopteUnPote</p>
    </footer>

</body>
</html>
