<?php
session_start();
// ============================================================
// LISTE.PHP — Page qui affiche tous les animaux disponibles
// L'utilisateur peut filtrer par catégorie via l'URL (?categorie=2)
// ============================================================

// 1. Connexion à la base de données
// On inclut config.php qui contient la variable $pdo
require 'config.php';

// -------------------------------------------------------
// ÉTAPE 1 : Récupérer le filtre de catégorie (si présent)
// -------------------------------------------------------
// Si l'utilisateur a choisi une catégorie dans le formulaire,
// sa valeur (ID) se trouve dans l'URL. Exemple : liste.php?categorie=3
$filtre_categorie = isset($_GET['categorie']) && $_GET['categorie'] !== '' # 
                    ? (int)$_GET['categorie']
                    : null;

// -------------------------------------------------------
// ÉTAPE 2 : Préparer et exécuter la requête SQL
// -------------------------------------------------------
// On veut récupérer les animaux "disponibles" ainsi que le nom de leur catégorie (JOIN)

if ($filtre_categorie !== null) {
    // CAS 1 : Un filtre est actif -> On utilise une requête préparée pour la sécurité
    $query = $pdo->prepare("
        SELECT a.*, c.nom_cat 
        FROM animaux a 
        JOIN categories c ON a.id_cat = c.id_cat 
        WHERE a.statut = 'disponible' 
          AND a.id_cat = :id_cat
        ORDER BY a.date_ajout DESC
    ");
    $query->execute([':id_cat' => $filtre_categorie]);
} else {
    // CAS 2 : Pas de filtre -> On affiche tout
    $query = $pdo->query("
        SELECT a.*, c.nom_cat 
        FROM animaux a 
        JOIN categories c ON a.id_cat = c.id_cat 
        WHERE a.statut = 'disponible' 
        ORDER BY a.date_ajout DESC
    ");
}

// On récupère tous les résultats dans un tableau PHP
$animaux = $query->fetchAll();

// -------------------------------------------------------
// ÉTAPE 3 : Récupérer les catégories pour le menu déroulant
// -------------------------------------------------------
$query_cat = $pdo->query("SELECT * FROM categories ORDER BY nom_cat ASC");
$categories = $query_cat->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>AdopteUnPote - Liste des animaux</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- HEADER : Navigation -->
    <header>
        <div class="logo">🐾 AdopteUnPote</div>
        <nav>
            <a href="index.php">Accueil</a>
            <a href="liste.php" style="font-weight: bold; color: #000;">Animaux</a>
            <a href="proposer.php">Proposer un animal</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php" style="color: #d32f2f; font-weight: bold;">Se déconnecter</a>
            <?php else: ?>
                <a href="login.php">Connexion/Inscription</a>
            <?php endif; ?>
        </nav>
    </header>

    <!-- FORMULAIRE DE RECHERCHE / FILTRE -->
    <section class="search-bar">
        <form action="liste.php" method="GET">
            <div class="search-group">
                <label>Filtrer par catégorie</label>
                <select name="categorie">
                    <option value="">Toutes les catégories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= $cat['id_cat'] ?>" <?= ($filtre_categorie === (int)$cat['id_cat']) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['nom_cat']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn-search">Filtrer</button>
            <?php if ($filtre_categorie): ?>
                <a href="liste.php" style="font-size: 0.8rem; color: #666; margin-left: 10px;">Réinitialiser</a>
            <?php endif; ?>
        </form>
    </section>

    <!-- CONTENU PRINCIPAL -->
    <main style="padding: 20px 50px;">
        
        <h2>
            <?php 
            if ($filtre_categorie) {
                echo "Résultats pour la catégorie sélectionnée";
            } else {
                echo "Tous nos animaux à l'adoption";
            }
            ?>
        </h2>

        <p><?= count($animaux) ?> animal(aux) trouvé(s)</p>

        <?php if (count($animaux) === 0): ?>
            <p>Désolé, aucun animal ne correspond à votre recherche.</p>
        <?php else: ?>
            <div class="grid-animaux">
                <?php foreach ($animaux as $animal): ?>
                    <div class="card">
                        <div class="card-img-container">
                            <!-- Image de l'animal -->
                            <img src="img/<?= htmlspecialchars($animal['image']) ?>" alt="<?= htmlspecialchars($animal['nom_animal']) ?>" class="animal-photo">
                            <span class="heart-icon">♡</span>
                        </div>
                        <div class="card-body">
                            <h3><?= htmlspecialchars($animal['nom_animal']) ?></h3>
                            <p class="age"><?= htmlspecialchars($animal['age']) ?></p>
                            <p class="category"><?= htmlspecialchars($animal['nom_cat']) ?></p>
                            <!-- Lien vers la fiche (à créer) -->
                            <a href="fiche.php?id=<?= $animal['id_animal'] ?>" class="btn-card">Voir plus</a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </main>

    <!-- FOOTER -->
    <footer>
        <p><a href="#">Contact</a> | <a href="#">Mentions Légales</a> | <a href="#">Réseaux Sociaux</a></p>
        <p>© 2026 AdopteUnPote</p>
    </footer>

</body>
</html>
