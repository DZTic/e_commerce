<?php
/**
 * ADMIN_USERS.PHP — Gestion des utilisateurs (Admin uniquement)
 */

session_start();
require_once 'config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit();
}

// CHANGEMENT DE RÔLE
if (isset($_POST['update_role'])) {
    $id_user = intval($_POST['id_user']);
    $new_role = $_POST['role'];
    
    // Empêcher l'admin de se retirer ses propres droits par erreur (facultatif mais plus sûr)
    if ($id_user !== $_SESSION['user_id']) {
        $stmt = $pdo->prepare("UPDATE utilisateurs SET role = ? WHERE id_user = ?");
        $stmt->execute([$new_role, $id_user]);
    }
}

// SUPPRESSION D'UN UTILISATEUR
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    if ($id !== $_SESSION['user_id']) {
        $stmt = $pdo->prepare("DELETE FROM utilisateurs WHERE id_user = ?");
        $stmt->execute([$id]);
    }
    header('Location: admin_users.php');
    exit();
}

$users = $pdo->query("SELECT * FROM utilisateurs ORDER BY login ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion Utilisateurs - AdopteUnPote</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🐾 Admin - AdopteUnPote</div>
        <nav>
            <a href="index.php">Retour au site</a>
            <a href="admin.php">Animaux</a>
            <a href="admin_categories.php">Catégories</a>
            <a href="admin_users.php" class="nav-active">Utilisateurs</a>
            <a href="demandes.php">Demandes</a>
        </nav>
    </header>

    <main class="container-admin" style="padding: 40px 50px;">
        <h1>Gestion des Utilisateurs</h1>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Login</th>
                    <th>Rôle actuel</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['id_user'] ?></td>
                    <td><?= htmlspecialchars($u['login']) ?></td>
                    <td>
                        <span class="badge" style="background: <?= $u['role'] === 'admin' ? '#ffebee' : ($u['role'] === 'gestionnaire' ? '#e3f2fd' : '#f5f5f5') ?>; color: <?= $u['role'] === 'admin' ? '#c62828' : ($u['role'] === 'gestionnaire' ? '#1976d2' : '#666') ?>;">
                            <?= htmlspecialchars($u['role']) ?>
                        </span>
                    </td>
                    <td>
                        <form method="POST" style="display: inline-flex; gap: 5px;">
                            <input type="hidden" name="id_user" value="<?= $u['id_user'] ?>">
                            <select name="role" style="padding: 5px; border-radius: 5px; border: 1px solid #ddd;">
                                <option value="user" <?= $u['role'] === 'user' ? 'selected' : '' ?>>User</option>
                                <option value="gestionnaire" <?= $u['role'] === 'gestionnaire' ? 'selected' : '' ?>>Gestionnaire</option>
                                <option value="admin" <?= $u['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                            </select>
                            <button type="submit" name="update_role" class="btn-edit" style="border: none; cursor: pointer;">OK</button>
                        </form>
                        <?php if ($u['id_user'] !== $_SESSION['user_id']): ?>
                            <a href="admin_users.php?delete_id=<?= $u['id_user'] ?>" class="btn-delete" onclick="return confirm('Supprimer cet utilisateur ?')">Supprimer</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>
