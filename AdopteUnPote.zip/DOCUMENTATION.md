# 🐾 Documentation du Projet : AdopteUnPote

Bienvenue dans la documentation complète de votre projet de site d'adoption d'animaux. Ce document explique comment le site fonctionne, comment les fichiers interagissent entre eux, et détaille les concepts techniques utilisés.

---

## 1. Vue d'ensemble du projet
**AdopteUnPote** est une application web dynamique permettant de parcourir des annonces d'animaux à l'adoption.
- **Langage** : PHP (Logique serveur)
- **Base de données** : SQLite (Stockage des données)
- **Design** : HTML5 & CSS3 (Structure et Style)

### Architecture des dossiers
```text
alia/
├── config.php      # Connexion à la base de données
├── db.sqlite       # La base de données contenant les animaux
├── index.php       # Page d'accueil (dernières annonces)
├── liste.php       # Liste complète avec filtres
├── login.php       # Page de connexion pour les utilisateurs
├── register.php    # Page d'inscription pour créer un compte
├── style.css       # Tous les styles graphiques
└── img/            # Dossier contenant les photos des animaux
```

---

## 2. Structure de la Base de Données (SQLite)
Le fichier `db.sqlite` contient plusieurs tables. Voici les plus importantes pour le moment :

### Table `categories`
| Colonne | Rôle |
| :--- | :--- |
| `id_cat` | Identifiant unique (Clé primaire) |
| `nom_cat` | Nom de la catégorie (ex: Chat, Chien, Rongeur) |

### Table `animaux`
| Colonne | Rôle |
| :--- | :--- |
| `id_animal` | Identifiant unique |
| `nom_animal`| Prénom de l'animal |
| `id_cat` | Lien vers la catégorie (Clé étrangère) |
| `image` | Nom du fichier image (ex: chat1.jpg) |
| `statut` | 'disponible' ou 'adopté' |
| `age` | Âge de l'animal (ex: 2 ans, Junior) |

### Table `utilisateurs` (Gestion des comptes)
| Colonne | Rôle |
| :--- | :--- |
| `id_user` | Identifiant unique de l'utilisateur |
| `login` | Nom d'utilisateur choisi à l'inscription |
| `password`| Mot de passe sécurisé (chiffré) |

---

## 3. Fonctionnement des fichiers

### 📁 config.php
C'est le "pont" entre votre code et la base de données.
- Il utilise **PDO** (PHP Data Objects).
- Il crée une variable `$pdo` que l'on réutilise dans tous les autres fichiers pour poser des questions à la base de données.

### 🏠 index.php (Accueil)
- **Logique** : Il demande à la base de données de lui donner les **4 derniers animaux** ajoutés.
- **Affichage** : Il présente une bannière "Hero" et affiche les 4 animaux sous forme de cartes.

### 🔍 liste.php (Recherche)
- **Logique** :
    1. Il vérifie si une catégorie a été choisie dans l'URL (ex: `?categorie=2`).
    2. Si oui, il filtre les résultats. Sinon, il affiche tout.
- **Affichage** : Un formulaire de sélection et une grille de tous les animaux disponibles.

### 🔐 login.php (Connexion)
- **Logique** :
    1. Vérifie si le nom d'utilisateur saisi existe dans la table `utilisateurs`.
    2. Compare le mot de passe saisi avec celui chiffré dans la base (`password_verify`).
    3. Si c'est correct, enregistre la session (`$_SESSION['user_id']`) et redirige vers l'accueil.
- **Affichage** : Un formulaire de connexion centré et stylisé de manière moderne.

### 📝 register.php (Inscription)
- **Logique** :
    1. Vérifie si le nom d'utilisateur est déjà pris.
    2. S'il est libre, chiffre le mot de passe (`password_hash`) par mesure de sécurité.
    3. Enregistre l'utilisateur en base de données, le connecte automatiquement et le redirige.
- **Affichage** : Un formulaire d'inscription reprenant exactement le même design que la connexion.

---

## 4. Guide Technique : PHP & HTML

### 🐘 Le PHP (Le Cerveau)
Voici les termes que vous trouverez dans le code et leur explication :

| Terme PHP | Explication simple |
| :--- | :--- |
| `require 'config.php'` | "Prends le contenu de config.php et mets-le ici". Essentiel pour la connexion DB. |
| `$query->execute()` | "Lance la commande SQL que j'ai préparée". |
| `$query->fetchAll()` | "Récupère TOUS les résultats de ma recherche et mets-les dans un tableau". |
| `foreach ($animaux as $animal)` | "Pour chaque animal trouvé, répète les instructions suivantes". C'est une boucle. |
| `$_GET['categorie']` | Récupère la valeur envoyée dans l'adresse URL (ce qui vient après le `?`). |
| `htmlspecialchars()` | **Sécurité** : Transforme les caractères spéciaux pour empêcher les pirates d'injecter du code malveillant. |
| `<?= $variable ?>` | Raccourci pour écrire `<?php echo $variable; ?>`. Sert à afficher du texte. |

### 📝 Le HTML (Le Squelette)
| Balise / Attribut | Explication |
| :--- | :--- |
| `<header>` / `<footer>` | Balises sémantiques qui définissent le haut et le bas de la page. |
| `<form method="GET">` | Envoie les données du formulaire directement dans l'URL pour que la page puisse les lire. |
| `<select>` / `<option>` | Crée la liste déroulante (le menu de choix). |
| `<img src="...">` | Affiche une image. Le chemin est construit dynamiquement en PHP : `img/<?= $animal['image'] ?>`. |

---

## 5. Le Design (CSS)
Le fichier `style.css` utilise des techniques modernes pour rendre le site beau :
- **Flexbox** : Utilisé dans le `<header>` pour espacer le logo et le menu.
- **CSS Grid** : Utilisé pour `.grid-animaux` afin de créer 4 colonnes parfaites qui s'alignent toutes seules.
- **Transitions** : `.card:hover` permet d'ajouter un effet d'ombre douce quand vous passez la souris sur un animal.

---

## 6. Comment ajouter un animal ?
Pour le moment, cela se fait en ajoutant une ligne dans la table `animaux` de votre base de données via un outil SQLite (ou via le futur formulaire `proposer.php`).
Il faut :
1. Lui donner un nom.
2. Lui attribuer un `id_cat` existant.
3. Mettre l'image dans le dossier `img/` et écrire son nom exact dans la base de données.

---

## 7. Les nouveaux fichiers : Catalogue, Fiche & Favoris

### Comment tous les fichiers se connectent entre eux

```
[ index.php ]  ──"Voir plus"──▶  [ fiche.php ]
[ index.php ]  ──"Animaux"───▶  [ catalogue.php ]
                                      │
                    ┌─────────────────┘
                    │  "Voir plus" sur chaque carte
                    ▼
              [ fiche.php ]
                    │
          ┌─────────┴────────────┐
          │ "Ajouter aux favoris"│ "Mes Favoris"
          ▼                      ▼
    [ BDD : favoris ]      [ favoris.php ]
          ▲                      │
          │                      │ "Voir la fiche"
          └──────────────────────┘

    Si non connecté sur fiche.php ou favoris.php
          ▼
     [ login.php ]
```

---

### 📋 catalogue.php

**Rôle :** Page de navigation principale. Affiche tous les animaux en grille avec des filtres dans la sidebar.

**Paramètres GET acceptés dans l'URL :**
| Paramètre | Exemple | Effet |
| :--- | :--- | :--- |
| `categorie` | `?categorie=2` | Filtre par catégorie |
| `race` | `?race=labrador` | Recherche textuelle sur le nom |
| `tri` | `?tri=age_asc` | Trie les résultats |
| `page` | `?page=2` | Pagination (10 animaux par page) |

**Connexions :**
- Inclut `config.php` pour la BDD
- Lien "Voir plus" → `fiche.php?id=X`
- Bouton cœur → POST vers `fiche.php` (ajout favori)
- Sidebar "Mes Favoris" → `favoris.php`
- Utilise `style.css` : classes `.page-catalogue`, `.sidebar`, `.grid-catalogue`, `.card-cat`, `.pagination`

---

### 🐾 fiche.php

**Rôle :** Affiche la fiche complète d'un seul animal. Gère aussi l'ajout aux favoris.

**Paramètre GET obligatoire :**
| Paramètre | Exemple | Effet |
| :--- | :--- | :--- |
| `id` | `?id=3` | Identifie quel animal afficher |

**Logique :**
1. Lit `$_GET['id']` et le sécurise avec `intval()` (protection injection)
2. Fait une requête SQL préparée avec `JOIN categories` pour avoir le nom de la catégorie
3. Si l'animal n'existe pas → redirection `catalogue.php`
4. Si bouton favori cliqué → vérifie la session → INSERT en BDD si nouveau favori
5. Affiche : image, badge catégorie, nom, statut, description, boutons

**Protection :** Si l'utilisateur clique "Ajouter aux favoris" sans être connecté → redirection automatique vers `login.php`

---

### ❤️ favoris.php

**Rôle :** Page personnelle qui affiche les animaux mis en favoris par l'utilisateur connecté, avec la possibilité d'ajouter un commentaire ou de retirer un favori.

**Protection :** Accès **réservé aux utilisateurs connectés**. Redirection automatique vers `login.php` si la session est absente.

**Trois actions POST possibles :**
| Bouton soumis | Action en BDD |
| :--- | :--- |
| `ajouter_favori` | `INSERT INTO favoris` |
| `mon_comm` | `UPDATE favoris SET commentaire_perso` |
| `supprimer_favori` | `DELETE FROM favoris` |

**Table `favoris` en BDD :**
```sql
CREATE TABLE favoris (
    id_favori         INTEGER PRIMARY KEY AUTOINCREMENT,
    id_user           INTEGER NOT NULL,   -- lié à utilisateurs
    id_animal         INTEGER NOT NULL,   -- lié à animaux
    commentaire_perso TEXT DEFAULT '',    -- note personnelle
    UNIQUE(id_user, id_animal)           -- un seul favori par paire
);
```

---

## 8. Glossaire rapide des classes CSS importantes

| Classe CSS | Fichier concerné | Rôle |
| :--- | :--- | :--- |
| `body.page-catalogue` | catalogue.php | Fond bleu clair |
| `.sidebar` | catalogue.php | Panneau de filtres blanc à gauche |
| `.grid-catalogue` | catalogue.php | Grille 5 colonnes |
| `.card-cat` | catalogue.php | Carte animal du catalogue |
| `.heart-btn` | catalogue.php | Bouton cœur circulaire |
| `.btn-voir-plus` | catalogue.php | Bouton vert "Voir plus" |
| `.pagination` | catalogue.php | Barre de numéros de page |
| `.container-fiche` | fiche.php | Conteneur centré de la fiche |
| `.fiche-flex` | fiche.php | Layout image + infos côte à côte |
| `.badge-cat` | fiche.php | Étiquette verte de catégorie |
| `.btn-fav` | fiche.php | Bouton favori (contour rouge) |
| `.btn-fav-active` | fiche.php | Bouton favori (rouge plein = déjà en favori) |
| `.grid-favoris` | favoris.php | Grille 2 colonnes des favoris |
| `.card-favori` | favoris.php | Carte enrichie avec formulaire commentaire |
| `.textarea-comm` | favoris.php | Zone de texte pour le commentaire perso |

