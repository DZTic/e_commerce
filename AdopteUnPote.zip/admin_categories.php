<?php
/**
 * ADMIN_CATEGORIES.PHP — Gestion des catégories (Admin uniquement)
 */

session_start();
require_once 'config.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit();
}

// AJOUT D'UNE CATÉGORIE
if (isset($_POST['ajouter_cat'])) {
    $nom_cat = trim($_POST['nom_cat']);
    if (!empty($nom_cat)) {
        $stmt = $pdo->prepare("INSERT INTO categories (nom_cat) VALUES (?)");
        $stmt->execute([$nom_cat]);
    }
}

// SUPPRESSION D'UNE CATÉGORIE
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    // On pourrait vérifier s'il y a des animaux dans cette catégorie avant...
    $stmt = $pdo->prepare("DELETE FROM categories WHERE id_cat = ?");
    $stmt->execute([$id]);
    header('Location: admin_categories.php');
    exit();
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY nom_cat ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion Catégories - AdopteUnPote</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🐾 Admin - AdopteUnPote</div>
        <nav>
            <a href="index.php">Retour au site</a>
            <a href="admin.php">Animaux</a>
            <a href="admin_categories.php" class="nav-active">Catégories</a>
            <a href="admin_users.php">Utilisateurs</a>
            <a href="demandes.php">Demandes</a>
        </nav>
    </header>

    <main class="container-admin" style="padding: 40px 50px;">
        <h1>Gestion des Catégories</h1>

        <div style="background: #fff; padding: 20px; border-radius: 10px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.05);">
            <h3>Ajouter une catégorie</h3>
            <form method="POST" style="display: flex; gap: 10px;">
                <input type="text" name="nom_cat" placeholder="Nom de la catégorie" required style="padding: 10px; border: 1px solid #ddd; border-radius: 5px; flex: 1;">
                <button type="submit" name="ajouter_cat" class="btn-filter" style="width: auto; padding: 10px 20px;">Ajouter</button>
            </form>
        </div>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom de la catégorie</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($categories as $cat): ?>
                <tr>
                    <td><?= $cat['id_cat'] ?></td>
                    <td><?= htmlspecialchars($cat['nom_cat']) ?></td>
                    <td>
                        <a href="admin_categories.php?delete_id=<?= $cat['id_cat'] ?>" class="btn-delete" onclick="return confirm('Supprimer cette catégorie ?')">Supprimer</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>
